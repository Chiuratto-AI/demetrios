//! # Demetrios Abstract Syntax Tree
//!
//! Complete AST definitions for the D programming language.
//!
//! ## Node Categories
//!
//! - **Items**: Top-level declarations (functions, structs, enums, effects, etc.)
//! - **Statements**: Imperative constructs (let, return, if, match, etc.)
//! - **Expressions**: Values and computations
//! - **Types**: Type expressions
//! - **Patterns**: Pattern matching constructs

use crate::common::{Span, Ident, NodeId};

/// Complete program AST
#[derive(Debug, Clone)]
pub struct Ast {
    pub items: Vec<Item>,
}

// ============================================================
// ITEMS
// ============================================================

/// Top-level item
#[derive(Debug, Clone)]
pub enum Item {
    Module(ModuleDef),
    Import(ImportDef),
    Function(FnDef),
    Kernel(KernelDef),
    Struct(StructDef),
    Enum(EnumDef),
    TypeAlias(TypeAliasDef),
    Effect(EffectDef),
    Const(ConstDef),
    Trait(TraitDef),
    Impl(ImplDef),
    Stmt(Stmt),
}

/// Visibility modifier
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum Visibility {
    #[default]
    Private,
    Public,
    Crate,
}

/// Type modifiers (linear, affine)
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct TypeModifiers {
    pub linear: bool,
    pub affine: bool,
}

/// Module declaration: `module path.to.module`
#[derive(Debug, Clone)]
pub struct ModuleDef {
    pub id: NodeId,
    pub path: Vec<Ident>,
    pub span: Span,
}

/// Import declaration: `import path` or `from path import { items }`
#[derive(Debug, Clone)]
pub struct ImportDef {
    pub id: NodeId,
    pub path: Vec<Ident>,
    pub items: Option<Vec<Ident>>,
    pub span: Span,
}

/// Function definition
#[derive(Debug, Clone)]
pub struct FnDef {
    pub id: NodeId,
    pub vis: Visibility,
    pub modifiers: TypeModifiers,
    pub name: Ident,
    pub generics: Vec<GenericParam>,
    pub params: Vec<Param>,
    pub return_type: Option<Box<Type>>,
    pub effects: Vec<EffectRef>,
    pub body: Block,
    pub span: Span,
}

/// GPU kernel definition
#[derive(Debug, Clone)]
pub struct KernelDef {
    pub id: NodeId,
    pub name: Ident,
    pub params: Vec<Param>,
    pub body: Block,
    pub span: Span,
}

/// Struct definition
#[derive(Debug, Clone)]
pub struct StructDef {
    pub id: NodeId,
    pub vis: Visibility,
    pub modifiers: TypeModifiers,
    pub name: Ident,
    pub generics: Vec<GenericParam>,
    pub fields: Vec<Field>,
    pub span: Span,
}

/// Enum definition
#[derive(Debug, Clone)]
pub struct EnumDef {
    pub id: NodeId,
    pub vis: Visibility,
    pub name: Ident,
    pub generics: Vec<GenericParam>,
    pub variants: Vec<Variant>,
    pub span: Span,
}

/// Type alias: `type Name = Type`
#[derive(Debug, Clone)]
pub struct TypeAliasDef {
    pub id: NodeId,
    pub vis: Visibility,
    pub name: Ident,
    pub generics: Vec<GenericParam>,
    pub ty: Box<Type>,
    pub span: Span,
}

/// Effect definition
#[derive(Debug, Clone)]
pub struct EffectDef {
    pub id: NodeId,
    pub vis: Visibility,
    pub name: Ident,
    pub ops: Vec<EffectOp>,
    pub span: Span,
}

/// Effect operation
#[derive(Debug, Clone)]
pub struct EffectOp {
    pub id: NodeId,
    pub name: Ident,
    pub params: Vec<Param>,
    pub return_type: Option<Box<Type>>,
    pub span: Span,
}

/// Constant definition
#[derive(Debug, Clone)]
pub struct ConstDef {
    pub id: NodeId,
    pub vis: Visibility,
    pub name: Ident,
    pub ty: Option<Box<Type>>,
    pub value: Box<Expr>,
    pub span: Span,
}

/// Trait definition
#[derive(Debug, Clone)]
pub struct TraitDef {
    pub id: NodeId,
    pub vis: Visibility,
    pub name: Ident,
    pub generics: Vec<GenericParam>,
    pub bounds: Vec<TypeBound>,
    pub items: Vec<TraitItem>,
    pub span: Span,
}

/// Trait item
#[derive(Debug, Clone)]
pub enum TraitItem {
    Function(FnDef),
    Type(TypeAliasDef),
    Const(ConstDef),
}

/// Implementation block
#[derive(Debug, Clone)]
pub struct ImplDef {
    pub id: NodeId,
    pub generics: Vec<GenericParam>,
    pub trait_ref: Option<Path>,
    pub self_type: Box<Type>,
    pub items: Vec<ImplItem>,
    pub span: Span,
}

/// Impl item
#[derive(Debug, Clone)]
pub enum ImplItem {
    Function(FnDef),
    Type(TypeAliasDef),
    Const(ConstDef),
}

// ============================================================
// GENERICS
// ============================================================

/// Generic parameter
#[derive(Debug, Clone)]
pub struct GenericParam {
    pub id: NodeId,
    pub name: Ident,
    pub bounds: Vec<TypeBound>,
}

/// Type bound
#[derive(Debug, Clone)]
pub enum TypeBound {
    Trait(Path),
    Lifetime(Ident),
}

/// Function parameter
#[derive(Debug, Clone)]
pub struct Param {
    pub id: NodeId,
    pub name: Ident,
    pub ty: Box<Type>,
}

/// Struct field
#[derive(Debug, Clone)]
pub struct Field {
    pub id: NodeId,
    pub name: Ident,
    pub ty: Box<Type>,
}

/// Enum variant
#[derive(Debug, Clone)]
pub struct Variant {
    pub id: NodeId,
    pub name: Ident,
    pub fields: Vec<Field>,
}

/// Effect reference
#[derive(Debug, Clone)]
pub enum EffectRef {
    IO(Span),
    Mut(Span),
    Alloc(Span),
    Panic(Span),
    Async(Span),
    GPU(Span),
    Prob(Span),
    Div(Span),
    Named(Ident),
}

// ============================================================
// TYPES
// ============================================================

/// Type expression
#[derive(Debug, Clone)]
pub enum Type {
    /// Named type: `int`, `MyStruct`
    Named(Path, Span),
    
    /// Generic type: `Vec<int>`, `Result<T, E>`
    Generic(Path, Vec<Type>, Span),
    
    /// Reference: `&T`, `&!T`
    Ref(RefKind, Box<Type>, Option<Ident>, Span),
    
    /// Owned type: `own T`
    Own(Box<Type>, Span),
    
    /// Linear type: `linear T`
    Linear(Box<Type>, Span),
    
    /// Affine type: `affine T`
    Affine(Box<Type>, Span),
    
    /// Unit type: `()`
    Unit(Span),
    
    /// Tuple: `(A, B, C)`
    Tuple(Vec<Type>, Span),
    
    /// Array: `[T; n]` or slice `[T]`
    Array(Box<Type>, Option<Box<Expr>>, Span),
    
    /// Function type: `fn(A, B) -> C with E`
    Function(Box<FnType>),
    
    /// Refined type: `{ x: T | predicate }`
    Refined(Box<Type>, Ident, Box<Expr>, Span),
    
    /// Unit-annotated type: `T<unit>`
    UnitAnnotated(Box<Type>, UnitExpr, Span),
    
    /// Inferred type (placeholder)
    Infer(Span),
    
    /// Error type (for recovery)
    Error(Span),
}

impl Type {
    pub fn span(&self) -> Span {
        match self {
            Type::Named(_, s) => *s,
            Type::Generic(_, _, s) => *s,
            Type::Ref(_, _, _, s) => *s,
            Type::Own(_, s) => *s,
            Type::Linear(_, s) => *s,
            Type::Affine(_, s) => *s,
            Type::Unit(s) => *s,
            Type::Tuple(_, s) => *s,
            Type::Array(_, _, s) => *s,
            Type::Function(f) => f.span,
            Type::Refined(_, _, _, s) => *s,
            Type::UnitAnnotated(_, _, s) => *s,
            Type::Infer(s) => *s,
            Type::Error(s) => *s,
        }
    }
}

/// Reference kind
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RefKind {
    Shared,     // &T
    Exclusive,  // &!T
}

/// Function type
#[derive(Debug, Clone)]
pub struct FnType {
    pub params: Vec<Type>,
    pub return_type: Box<Type>,
    pub effects: Vec<EffectRef>,
    pub span: Span,
}

/// Unit expression (for units of measure)
#[derive(Debug, Clone)]
pub struct UnitExpr {
    pub base: String,
    pub power: i32,
}

/// Path (e.g., `std::collections::Vec`)
#[derive(Debug, Clone)]
pub struct Path {
    pub segments: Vec<Ident>,
    pub span: Span,
}

impl Path {
    pub fn is_simple(&self) -> bool {
        self.segments.len() == 1
    }
}

// ============================================================
// STATEMENTS
// ============================================================

/// Statement
#[derive(Debug, Clone)]
pub enum Stmt {
    Let(LetStmt),
    Return(ReturnStmt),
    If(IfStmt),
    Match(MatchStmt),
    For(ForStmt),
    While(WhileStmt),
    Loop(LoopStmt),
    Break(BreakStmt),
    Continue(ContinueStmt),
    Handle(HandleStmt),
    Expr(ExprStmt),
}

/// Let binding: `let x: T = expr` or `var x: T = expr`
#[derive(Debug, Clone)]
pub struct LetStmt {
    pub id: NodeId,
    pub mutable: bool,
    pub name: Ident,
    pub ty: Option<Box<Type>>,
    pub value: Box<Expr>,
    pub span: Span,
}

/// Return statement
#[derive(Debug, Clone)]
pub struct ReturnStmt {
    pub id: NodeId,
    pub value: Option<Box<Expr>>,
    pub span: Span,
}

/// If statement
#[derive(Debug, Clone)]
pub struct IfStmt {
    pub id: NodeId,
    pub cond: Box<Expr>,
    pub then_block: Block,
    pub else_block: Option<Block>,
    pub span: Span,
}

/// Match statement
#[derive(Debug, Clone)]
pub struct MatchStmt {
    pub id: NodeId,
    pub scrutinee: Box<Expr>,
    pub arms: Vec<MatchArm>,
    pub span: Span,
}

/// Match arm
#[derive(Debug, Clone)]
pub struct MatchArm {
    pub id: NodeId,
    pub pattern: Pattern,
    pub body: Box<Expr>,
}

/// For loop
#[derive(Debug, Clone)]
pub struct ForStmt {
    pub id: NodeId,
    pub var: Ident,
    pub iter: Box<Expr>,
    pub body: Block,
    pub span: Span,
}

/// While loop
#[derive(Debug, Clone)]
pub struct WhileStmt {
    pub id: NodeId,
    pub cond: Box<Expr>,
    pub body: Block,
    pub span: Span,
}

/// Loop (infinite)
#[derive(Debug, Clone)]
pub struct LoopStmt {
    pub id: NodeId,
    pub body: Block,
    pub span: Span,
}

/// Break statement
#[derive(Debug, Clone)]
pub struct BreakStmt {
    pub id: NodeId,
    pub value: Option<Box<Expr>>,
    pub span: Span,
}

/// Continue statement
#[derive(Debug, Clone)]
pub struct ContinueStmt {
    pub id: NodeId,
    pub span: Span,
}

/// Effect handler statement
#[derive(Debug, Clone)]
pub struct HandleStmt {
    pub id: NodeId,
    pub name: Ident,
    pub effect: EffectRef,
    pub handlers: Vec<HandlerCase>,
    pub span: Span,
}

/// Handler case
#[derive(Debug, Clone)]
pub struct HandlerCase {
    pub id: NodeId,
    pub op: Ident,
    pub params: Vec<Param>,
    pub body: Box<Expr>,
}

/// Expression statement
#[derive(Debug, Clone)]
pub struct ExprStmt {
    pub id: NodeId,
    pub expr: Box<Expr>,
}

/// Block
#[derive(Debug, Clone)]
pub struct Block {
    pub id: NodeId,
    pub stmts: Vec<Stmt>,
    pub span: Span,
}

// ============================================================
// PATTERNS
// ============================================================

/// Pattern
#[derive(Debug, Clone)]
pub enum Pattern {
    /// Wildcard: `_`
    Wildcard(Span),
    
    /// Literal: `42`, `true`
    Literal(Literal, Span),
    
    /// Binding: `x`
    Binding(Ident, Span),
    
    /// Variant: `Some(x)`, `None`
    Variant(Path, Vec<Pattern>, Span),
    
    /// Struct: `Point { x, y }`
    Struct(Path, Vec<(Ident, Pattern)>, Span),
    
    /// Tuple: `(a, b, c)`
    Tuple(Vec<Pattern>, Span),
    
    /// Array: `[a, b, c]`
    Array(Vec<Pattern>, Span),
    
    /// Or pattern: `A | B`
    Or(Box<Pattern>, Box<Pattern>, Span),
}

// ============================================================
// EXPRESSIONS
// ============================================================

/// Expression
#[derive(Debug, Clone)]
pub enum Expr {
    Literal(LiteralExpr),
    Path(PathExpr),
    Binary(BinaryExpr),
    Unary(UnaryExpr),
    Call(CallExpr),
    MethodCall(MethodCallExpr),
    Index(IndexExpr),
    Field(FieldExpr),
    Cast(CastExpr),
    Tuple(TupleExpr),
    Array(ArrayExpr),
    Struct(StructExpr),
    If(IfExpr),
    Match(MatchExpr),
    Block(BlockExpr),
    Lambda(LambdaExpr),
    With(WithExpr),
    Resume(ResumeExpr),
}

impl Expr {
    pub fn span(&self) -> Span {
        match self {
            Expr::Literal(e) => e.span,
            Expr::Path(e) => e.span,
            Expr::Binary(e) => e.span,
            Expr::Unary(e) => e.span,
            Expr::Call(e) => e.span,
            Expr::MethodCall(e) => e.span,
            Expr::Index(e) => e.span,
            Expr::Field(e) => e.span,
            Expr::Cast(e) => e.span,
            Expr::Tuple(e) => e.span,
            Expr::Array(e) => e.span,
            Expr::Struct(e) => e.span,
            Expr::If(e) => e.span,
            Expr::Match(e) => e.span,
            Expr::Block(e) => e.span,
            Expr::Lambda(e) => e.span,
            Expr::With(e) => e.span,
            Expr::Resume(e) => e.span,
        }
    }
}

/// Literal expression
#[derive(Debug, Clone)]
pub struct LiteralExpr {
    pub id: NodeId,
    pub value: Literal,
    pub span: Span,
}

/// Literal value
#[derive(Debug, Clone)]
pub enum Literal {
    Unit,
    Bool(bool),
    Int(i64),
    Float(f64),
    Char(char),
    String(String),
    UnitValue { value: f64, unit: String },
}

/// Path expression
#[derive(Debug, Clone)]
pub struct PathExpr {
    pub id: NodeId,
    pub path: Path,
    pub span: Span,
}

/// Binary expression
#[derive(Debug, Clone)]
pub struct BinaryExpr {
    pub id: NodeId,
    pub op: BinOp,
    pub lhs: Box<Expr>,
    pub rhs: Box<Expr>,
    pub span: Span,
}

/// Binary operator
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BinOp {
    Add, Sub, Mul, Div, Mod, Pow,
    Eq, Ne, Lt, Le, Gt, Ge,
    And, Or,
    Assign,
}

/// Unary expression
#[derive(Debug, Clone)]
pub struct UnaryExpr {
    pub id: NodeId,
    pub op: UnaryOp,
    pub operand: Box<Expr>,
    pub span: Span,
}

/// Unary operator
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UnaryOp {
    Neg,      // -x
    Not,      // !x
    Ref,      // &x
    RefMut,   // &!x
    Deref,    // *x
}

/// Call expression
#[derive(Debug, Clone)]
pub struct CallExpr {
    pub id: NodeId,
    pub callee: Box<Expr>,
    pub args: Vec<Expr>,
    pub span: Span,
}

/// Method call expression
#[derive(Debug, Clone)]
pub struct MethodCallExpr {
    pub id: NodeId,
    pub receiver: Box<Expr>,
    pub method: Ident,
    pub args: Vec<Expr>,
    pub span: Span,
}

/// Index expression
#[derive(Debug, Clone)]
pub struct IndexExpr {
    pub id: NodeId,
    pub base: Box<Expr>,
    pub index: Box<Expr>,
    pub span: Span,
}

/// Field access expression
#[derive(Debug, Clone)]
pub struct FieldExpr {
    pub id: NodeId,
    pub base: Box<Expr>,
    pub field: Ident,
    pub span: Span,
}

/// Cast expression
#[derive(Debug, Clone)]
pub struct CastExpr {
    pub id: NodeId,
    pub expr: Box<Expr>,
    pub ty: Box<Type>,
    pub span: Span,
}

/// Tuple expression
#[derive(Debug, Clone)]
pub struct TupleExpr {
    pub id: NodeId,
    pub elements: Vec<Expr>,
    pub span: Span,
}

/// Array expression
#[derive(Debug, Clone)]
pub struct ArrayExpr {
    pub id: NodeId,
    pub elements: Vec<Expr>,
    pub span: Span,
}

/// Struct expression
#[derive(Debug, Clone)]
pub struct StructExpr {
    pub id: NodeId,
    pub path: Path,
    pub fields: Vec<(Ident, Expr)>,
    pub span: Span,
}

/// If expression
#[derive(Debug, Clone)]
pub struct IfExpr {
    pub id: NodeId,
    pub cond: Box<Expr>,
    pub then_block: Block,
    pub else_block: Option<Block>,
    pub span: Span,
}

/// Match expression
#[derive(Debug, Clone)]
pub struct MatchExpr {
    pub id: NodeId,
    pub scrutinee: Box<Expr>,
    pub arms: Vec<MatchArm>,
    pub span: Span,
}

/// Block expression
#[derive(Debug, Clone)]
pub struct BlockExpr {
    pub id: NodeId,
    pub block: Block,
    pub span: Span,
}

/// Lambda expression
#[derive(Debug, Clone)]
pub struct LambdaExpr {
    pub id: NodeId,
    pub params: Vec<Param>,
    pub return_type: Option<Box<Type>>,
    pub body: Box<Expr>,
    pub span: Span,
}

/// With expression (effect handler scope)
#[derive(Debug, Clone)]
pub struct WithExpr {
    pub id: NodeId,
    pub handler: Ident,
    pub body: Block,
    pub span: Span,
}

/// Resume expression
#[derive(Debug, Clone)]
pub struct ResumeExpr {
    pub id: NodeId,
    pub value: Box<Expr>,
    pub span: Span,
}
