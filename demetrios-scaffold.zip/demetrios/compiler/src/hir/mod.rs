//! # Demetrios HIR (High-level IR)
//!
//! The HIR is the typed representation after type checking.
//! It preserves type information and resolved names.

use crate::ast;
use crate::common::{Span, NodeId};

/// HIR module (typed AST)
#[derive(Debug, Clone)]
pub struct Hir {
    pub items: Vec<HirItem>,
}

/// HIR item
#[derive(Debug, Clone)]
pub enum HirItem {
    Function(HirFn),
    Struct(HirStruct),
    Enum(HirEnum),
    // ... more items
}

/// HIR function
#[derive(Debug, Clone)]
pub struct HirFn {
    pub id: NodeId,
    pub name: String,
    pub ty: HirFnType,
    pub body: HirBlock,
}

/// HIR function type
#[derive(Debug, Clone)]
pub struct HirFnType {
    pub params: Vec<HirType>,
    pub return_type: Box<HirType>,
    pub effects: Vec<HirEffect>,
}

/// HIR type
#[derive(Debug, Clone)]
pub enum HirType {
    Primitive(PrimitiveType),
    Struct(NodeId),
    Enum(NodeId),
    Ref(RefKind, Box<HirType>),
    Linear(Box<HirType>),
    Affine(Box<HirType>),
    Array(Box<HirType>, Option<usize>),
    Tuple(Vec<HirType>),
    Function(Box<HirFnType>),
    Unit,
    Error,
}

/// Primitive type
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PrimitiveType {
    Bool,
    I8, I16, I32, I64, I128,
    U8, U16, U32, U64, U128,
    F32, F64,
    Char,
    String,
}

/// Reference kind
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RefKind {
    Shared,
    Exclusive,
}

/// HIR effect
#[derive(Debug, Clone)]
pub enum HirEffect {
    IO,
    Mut,
    Alloc,
    Panic,
    Async,
    GPU,
    Prob,
    Div,
    Named(NodeId),
}

/// HIR struct
#[derive(Debug, Clone)]
pub struct HirStruct {
    pub id: NodeId,
    pub name: String,
    pub fields: Vec<HirField>,
    pub is_linear: bool,
    pub is_affine: bool,
}

/// HIR field
#[derive(Debug, Clone)]
pub struct HirField {
    pub name: String,
    pub ty: HirType,
}

/// HIR enum
#[derive(Debug, Clone)]
pub struct HirEnum {
    pub id: NodeId,
    pub name: String,
    pub variants: Vec<HirVariant>,
}

/// HIR variant
#[derive(Debug, Clone)]
pub struct HirVariant {
    pub name: String,
    pub fields: Vec<HirField>,
}

/// HIR block
#[derive(Debug, Clone)]
pub struct HirBlock {
    pub stmts: Vec<HirStmt>,
    pub ty: HirType,
}

/// HIR statement
#[derive(Debug, Clone)]
pub enum HirStmt {
    Let {
        name: String,
        ty: HirType,
        value: HirExpr,
        mutable: bool,
    },
    Expr(HirExpr),
    // ... more statements
}

/// HIR expression (placeholder)
#[derive(Debug, Clone)]
pub struct HirExpr {
    pub kind: HirExprKind,
    pub ty: HirType,
    pub span: Span,
}

/// HIR expression kind
#[derive(Debug, Clone)]
pub enum HirExprKind {
    Literal(ast::Literal),
    Var(NodeId),
    Binary(ast::BinOp, Box<HirExpr>, Box<HirExpr>),
    Unary(ast::UnaryOp, Box<HirExpr>),
    Call(Box<HirExpr>, Vec<HirExpr>),
    // ... more expressions
}
