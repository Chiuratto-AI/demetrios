//! # Demetrios HLIR (High-Level Intermediate Representation)
//!
//! SSA-based IR ready for optimization and lowering to MLIR.
//!
//! ## Structure
//!
//! ```text
//! Module
//!   └── Function
//!         └── BasicBlock
//!               ├── Instructions
//!               └── Terminator
//! ```

use crate::common::NodeId;

/// HLIR module
#[derive(Debug, Clone)]
pub struct HlirModule {
    pub name: String,
    pub functions: Vec<HlirFunction>,
    pub structs: Vec<HlirStruct>,
    pub globals: Vec<HlirGlobal>,
}

/// HLIR function
#[derive(Debug, Clone)]
pub struct HlirFunction {
    pub name: String,
    pub signature: HlirSignature,
    pub blocks: Vec<BasicBlock>,
    pub locals: Vec<HlirLocal>,
}

/// Function signature
#[derive(Debug, Clone)]
pub struct HlirSignature {
    pub params: Vec<HlirType>,
    pub return_type: HlirType,
    pub effects: Vec<HlirEffect>,
}

/// Basic block
#[derive(Debug, Clone)]
pub struct BasicBlock {
    pub id: BlockId,
    pub params: Vec<Value>,
    pub instructions: Vec<Instruction>,
    pub terminator: Terminator,
}

/// Block ID
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct BlockId(pub u32);

/// SSA value
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Value(pub u32);

/// Local variable
#[derive(Debug, Clone)]
pub struct HlirLocal {
    pub id: Value,
    pub ty: HlirType,
    pub name: Option<String>,
}

/// Instruction
#[derive(Debug, Clone)]
pub enum Instruction {
    // Constants
    Const(Value, Constant),
    
    // Arithmetic
    BinOp(Value, BinOp, Value, Value),
    UnOp(Value, UnOp, Value),
    
    // Memory
    Alloc(Value, HlirType, AllocKind),
    Load(Value, Value),
    Store(Value, Value),
    GetElementPtr(Value, Value, Vec<u32>),
    
    // Ownership
    Move(Value, Value),
    Copy(Value, Value),
    Drop(Value),
    Borrow(Value, Value, BorrowKind),
    
    // Effects
    Perform(Value, EffectOp, Vec<Value>),
    
    // GPU
    GpuAlloc(Value, HlirType, Value),
    GpuFree(Value),
    GpuCopyH2D(Value, Value, Value),
    GpuCopyD2H(Value, Value, Value),
    GpuLaunch {
        kernel: String,
        grid: (Value, Value, Value),
        block: (Value, Value, Value),
        args: Vec<Value>,
    },
    
    // Calls
    Call(Option<Value>, String, Vec<Value>),
}

/// Terminator
#[derive(Debug, Clone)]
pub enum Terminator {
    Return(Option<Value>),
    Branch(BlockId),
    CondBranch(Value, BlockId, BlockId),
    Switch(Value, Vec<(Constant, BlockId)>, BlockId),
    Resume(Value),
    Unreachable,
}

/// Constant value
#[derive(Debug, Clone)]
pub enum Constant {
    Unit,
    Bool(bool),
    Int(i64),
    Float(f64),
    String(String),
}

/// Binary operation
#[derive(Debug, Clone, Copy)]
pub enum BinOp {
    Add, Sub, Mul, Div, Mod, Pow,
    Eq, Ne, Lt, Le, Gt, Ge,
    And, Or,
    BitAnd, BitOr, BitXor,
    Shl, Shr,
}

/// Unary operation
#[derive(Debug, Clone, Copy)]
pub enum UnOp {
    Neg, Not, BitNot,
}

/// Allocation kind
#[derive(Debug, Clone, Copy)]
pub enum AllocKind {
    Stack,
    Heap,
    Gpu,
}

/// Borrow kind
#[derive(Debug, Clone, Copy)]
pub enum BorrowKind {
    Shared,
    Exclusive,
}

/// Effect operation
#[derive(Debug, Clone)]
pub struct EffectOp {
    pub effect: HlirEffect,
    pub operation: String,
}

/// HLIR type
#[derive(Debug, Clone)]
pub enum HlirType {
    Void,
    Bool,
    I8, I16, I32, I64,
    U8, U16, U32, U64,
    F32, F64,
    Ptr(Box<HlirType>),
    Array(Box<HlirType>, usize),
    Struct(String),
    Function(Box<HlirSignature>),
}

/// HLIR effect
#[derive(Debug, Clone)]
pub enum HlirEffect {
    IO, Mut, Alloc, Panic, Async, GPU, Prob, Div,
    Named(String),
}

/// HLIR struct definition
#[derive(Debug, Clone)]
pub struct HlirStruct {
    pub name: String,
    pub fields: Vec<(String, HlirType)>,
    pub is_linear: bool,
    pub is_affine: bool,
}

/// HLIR global
#[derive(Debug, Clone)]
pub struct HlirGlobal {
    pub name: String,
    pub ty: HlirType,
    pub value: Option<Constant>,
}

/// Lower HIR to HLIR
pub fn lower(hir: &crate::hir::Hir) -> miette::Result<HlirModule> {
    // TODO: Implement lowering
    Ok(HlirModule {
        name: "main".to_string(),
        functions: Vec::new(),
        structs: Vec::new(),
        globals: Vec::new(),
    })
}
