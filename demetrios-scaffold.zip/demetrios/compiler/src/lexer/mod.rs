//! # Demetrios Lexer
//!
//! Lexical analysis for the D programming language.
//!
//! ## Token Categories
//!
//! - **Keywords**: `let`, `var`, `fn`, `kernel`, `struct`, `enum`, `linear`, `affine`, etc.
//! - **Operators**: `+`, `-`, `*`, `/`, `&`, `&!`, `->`, `=>`, `with`, etc.
//! - **Literals**: integers, floats, strings, unit-annotated values
//! - **Identifiers**: user-defined names
//! - **Effects**: `IO`, `Mut`, `Alloc`, `GPU`, `Prob`, `Panic`, `Async`, `Div`

mod tokens;

pub use tokens::*;

use crate::common::Span;
use logos::Logos;
use miette::Result;

/// Lex source code into tokens
pub fn lex(source: &str) -> Result<Vec<Token>> {
    let mut tokens = Vec::new();
    let mut lexer = TokenKind::lexer(source);
    
    while let Some(result) = lexer.next() {
        let span = lexer.span();
        let kind = result.unwrap_or(TokenKind::Error);
        
        tokens.push(Token {
            kind,
            span: Span::from(span),
        });
    }
    
    // Add EOF
    let len = source.len() as u32;
    tokens.push(Token {
        kind: TokenKind::Eof,
        span: Span::new(len, len),
    });
    
    Ok(tokens)
}

/// A single token
#[derive(Debug, Clone, PartialEq)]
pub struct Token {
    pub kind: TokenKind,
    pub span: Span,
}

impl Token {
    pub fn is(&self, kind: TokenKind) -> bool {
        self.kind == kind
    }
    
    pub fn is_keyword(&self) -> bool {
        matches!(self.kind,
            TokenKind::Let | TokenKind::Var | TokenKind::Const |
            TokenKind::Fn | TokenKind::Kernel | TokenKind::Return |
            TokenKind::If | TokenKind::Else | TokenKind::Match |
            TokenKind::For | TokenKind::While | TokenKind::Loop |
            TokenKind::Struct | TokenKind::Enum | TokenKind::Type |
            TokenKind::Linear | TokenKind::Affine | TokenKind::Own |
            TokenKind::Module | TokenKind::Import | TokenKind::Export | TokenKind::From |
            TokenKind::Effect | TokenKind::Handle | TokenKind::With | TokenKind::On |
            TokenKind::Resume | TokenKind::Perform |
            TokenKind::Where | TokenKind::As | TokenKind::In |
            TokenKind::True | TokenKind::False |
            TokenKind::Pub | TokenKind::Mut | TokenKind::Unsafe
        )
    }
    
    pub fn is_literal(&self) -> bool {
        matches!(self.kind,
            TokenKind::IntLit(_) | TokenKind::FloatLit(_) |
            TokenKind::StringLit(_) | TokenKind::CharLit(_) |
            TokenKind::True | TokenKind::False
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_lex_keywords() {
        let tokens = lex("let var fn kernel struct enum").unwrap();
        assert_eq!(tokens[0].kind, TokenKind::Let);
        assert_eq!(tokens[1].kind, TokenKind::Var);
        assert_eq!(tokens[2].kind, TokenKind::Fn);
        assert_eq!(tokens[3].kind, TokenKind::Kernel);
        assert_eq!(tokens[4].kind, TokenKind::Struct);
        assert_eq!(tokens[5].kind, TokenKind::Enum);
    }
    
    #[test]
    fn test_lex_operators() {
        let tokens = lex("+ - * / -> => &! & with").unwrap();
        assert_eq!(tokens[0].kind, TokenKind::Plus);
        assert_eq!(tokens[1].kind, TokenKind::Minus);
        assert_eq!(tokens[2].kind, TokenKind::Star);
        assert_eq!(tokens[3].kind, TokenKind::Slash);
        assert_eq!(tokens[4].kind, TokenKind::Arrow);
        assert_eq!(tokens[5].kind, TokenKind::FatArrow);
        assert_eq!(tokens[6].kind, TokenKind::AmpBang);
        assert_eq!(tokens[7].kind, TokenKind::Amp);
        assert_eq!(tokens[8].kind, TokenKind::With);
    }
    
    #[test]
    fn test_lex_literals() {
        let tokens = lex(r#"42 3.14 "hello" 'c' true false"#).unwrap();
        assert!(matches!(tokens[0].kind, TokenKind::IntLit(42)));
        assert!(matches!(tokens[1].kind, TokenKind::FloatLit(f) if (f - 3.14).abs() < 0.001));
        assert!(matches!(tokens[2].kind, TokenKind::StringLit(_)));
        assert!(matches!(tokens[3].kind, TokenKind::CharLit('c')));
        assert_eq!(tokens[4].kind, TokenKind::True);
        assert_eq!(tokens[5].kind, TokenKind::False);
    }
    
    #[test]
    fn test_lex_unit_literals() {
        let tokens = lex("500.0_mg 10.0_mL 1.5_hours").unwrap();
        assert!(matches!(tokens[0].kind, TokenKind::UnitLit { .. }));
        assert!(matches!(tokens[1].kind, TokenKind::UnitLit { .. }));
        assert!(matches!(tokens[2].kind, TokenKind::UnitLit { .. }));
    }
    
    #[test]
    fn test_lex_effects() {
        let tokens = lex("with IO, Mut, GPU, Prob").unwrap();
        assert_eq!(tokens[0].kind, TokenKind::With);
        assert_eq!(tokens[1].kind, TokenKind::EffectIO);
        assert_eq!(tokens[3].kind, TokenKind::EffectMut);
        assert_eq!(tokens[5].kind, TokenKind::EffectGPU);
        assert_eq!(tokens[7].kind, TokenKind::EffectProb);
    }
    
    #[test]
    fn test_lex_function() {
        let source = "fn add(a: int, b: int) -> int { a + b }";
        let tokens = lex(source).unwrap();
        assert_eq!(tokens[0].kind, TokenKind::Fn);
        assert!(matches!(tokens[1].kind, TokenKind::Ident(_)));
        assert_eq!(tokens[2].kind, TokenKind::LParen);
    }
    
    #[test]
    fn test_lex_linear_type() {
        let source = "linear struct FileHandle { fd: int }";
        let tokens = lex(source).unwrap();
        assert_eq!(tokens[0].kind, TokenKind::Linear);
        assert_eq!(tokens[1].kind, TokenKind::Struct);
    }
    
    #[test]
    fn test_lex_refinement() {
        let source = "type SafeDose = { dose: mg | dose > 0.0 }";
        let tokens = lex(source).unwrap();
        assert_eq!(tokens[0].kind, TokenKind::Type);
        assert_eq!(tokens[4].kind, TokenKind::LBrace);
        assert_eq!(tokens[8].kind, TokenKind::Pipe);
    }
}
