//! Token definitions for the Demetrios language
//!
//! Uses Logos for efficient lexical analysis.

use logos::Logos;

/// All token kinds in the D language
#[derive(Logos, Debug, Clone, PartialEq)]
#[logos(skip r"[ \t\r\n\f]+")]  // Skip whitespace
#[logos(skip r"//[^\n]*")]      // Skip line comments
#[logos(skip r"/\*[^*]*\*+(?:[^/*][^*]*\*+)*/")] // Skip block comments
pub enum TokenKind {
    // ============================================================
    // KEYWORDS - Core Language
    // ============================================================
    
    /// `let` - Immutable binding
    #[token("let")]
    Let,
    
    /// `var` - Mutable binding
    #[token("var")]
    Var,
    
    /// `const` - Compile-time constant
    #[token("const")]
    Const,
    
    /// `fn` - Function definition
    #[token("fn")]
    Fn,
    
    /// `kernel` - GPU kernel function
    #[token("kernel")]
    Kernel,
    
    /// `return` - Return from function
    #[token("return")]
    Return,
    
    // ============================================================
    // KEYWORDS - Control Flow
    // ============================================================
    
    /// `if` - Conditional
    #[token("if")]
    If,
    
    /// `else` - Alternative branch
    #[token("else")]
    Else,
    
    /// `match` - Pattern matching
    #[token("match")]
    Match,
    
    /// `for` - For loop
    #[token("for")]
    For,
    
    /// `while` - While loop
    #[token("while")]
    While,
    
    /// `loop` - Infinite loop
    #[token("loop")]
    Loop,
    
    /// `break` - Break from loop
    #[token("break")]
    Break,
    
    /// `continue` - Continue to next iteration
    #[token("continue")]
    Continue,
    
    // ============================================================
    // KEYWORDS - Types
    // ============================================================
    
    /// `struct` - Product type
    #[token("struct")]
    Struct,
    
    /// `enum` - Sum type
    #[token("enum")]
    Enum,
    
    /// `type` - Type alias
    #[token("type")]
    Type,
    
    /// `trait` - Trait definition
    #[token("trait")]
    Trait,
    
    /// `impl` - Implementation block
    #[token("impl")]
    Impl,
    
    /// `linear` - Linear type modifier
    #[token("linear")]
    Linear,
    
    /// `affine` - Affine type modifier
    #[token("affine")]
    Affine,
    
    /// `own` - Ownership transfer
    #[token("own")]
    Own,
    
    // ============================================================
    // KEYWORDS - Modules
    // ============================================================
    
    /// `module` - Module declaration
    #[token("module")]
    Module,
    
    /// `import` - Import declaration
    #[token("import")]
    Import,
    
    /// `export` - Export declaration
    #[token("export")]
    Export,
    
    /// `from` - Import from
    #[token("from")]
    From,
    
    /// `pub` - Public visibility
    #[token("pub")]
    Pub,
    
    // ============================================================
    // KEYWORDS - Effects
    // ============================================================
    
    /// `effect` - Effect declaration
    #[token("effect")]
    Effect,
    
    /// `handle` - Effect handler
    #[token("handle")]
    Handle,
    
    /// `with` - Effect annotation / handler scope
    #[token("with")]
    With,
    
    /// `on` - Handler case
    #[token("on")]
    On,
    
    /// `resume` - Resume computation
    #[token("resume")]
    Resume,
    
    /// `perform` - Perform effect operation
    #[token("perform")]
    Perform,
    
    // ============================================================
    // KEYWORDS - Other
    // ============================================================
    
    /// `where` - Type constraints
    #[token("where")]
    Where,
    
    /// `as` - Type cast
    #[token("as")]
    As,
    
    /// `in` - Membership
    #[token("in")]
    In,
    
    /// `mut` - Mutable modifier
    #[token("mut")]
    Mut,
    
    /// `unsafe` - Unsafe block
    #[token("unsafe")]
    Unsafe,
    
    /// `true` - Boolean true
    #[token("true")]
    True,
    
    /// `false` - Boolean false
    #[token("false")]
    False,
    
    // ============================================================
    // BUILT-IN EFFECTS
    // ============================================================
    
    /// `IO` effect
    #[token("IO")]
    EffectIO,
    
    /// `Mut` effect
    #[token("Mut")]
    EffectMut,
    
    /// `Alloc` effect
    #[token("Alloc")]
    EffectAlloc,
    
    /// `Panic` effect
    #[token("Panic")]
    EffectPanic,
    
    /// `Async` effect
    #[token("Async")]
    EffectAsync,
    
    /// `GPU` effect
    #[token("GPU")]
    EffectGPU,
    
    /// `Prob` effect (probabilistic)
    #[token("Prob")]
    EffectProb,
    
    /// `Div` effect (divergence)
    #[token("Div")]
    EffectDiv,
    
    // ============================================================
    // BUILT-IN TYPES
    // ============================================================
    
    #[token("int")]
    TyInt,
    #[token("i8")]
    TyI8,
    #[token("i16")]
    TyI16,
    #[token("i32")]
    TyI32,
    #[token("i64")]
    TyI64,
    #[token("i128")]
    TyI128,
    
    #[token("uint")]
    TyUint,
    #[token("u8")]
    TyU8,
    #[token("u16")]
    TyU16,
    #[token("u32")]
    TyU32,
    #[token("u64")]
    TyU64,
    #[token("u128")]
    TyU128,
    
    #[token("f32")]
    TyF32,
    #[token("f64")]
    TyF64,
    
    #[token("bool")]
    TyBool,
    #[token("char")]
    TyChar,
    #[token("string")]
    TyString,
    
    // ============================================================
    // OPERATORS - Arithmetic
    // ============================================================
    
    /// `+`
    #[token("+")]
    Plus,
    
    /// `-`
    #[token("-")]
    Minus,
    
    /// `*`
    #[token("*")]
    Star,
    
    /// `/`
    #[token("/")]
    Slash,
    
    /// `%`
    #[token("%")]
    Percent,
    
    /// `^` - Power
    #[token("^")]
    Caret,
    
    // ============================================================
    // OPERATORS - Comparison
    // ============================================================
    
    /// `==`
    #[token("==")]
    EqEq,
    
    /// `!=`
    #[token("!=")]
    BangEq,
    
    /// `<`
    #[token("<")]
    Lt,
    
    /// `<=`
    #[token("<=")]
    Le,
    
    /// `>`
    #[token(">")]
    Gt,
    
    /// `>=`
    #[token(">=")]
    Ge,
    
    // ============================================================
    // OPERATORS - Logical
    // ============================================================
    
    /// `&&`
    #[token("&&")]
    AndAnd,
    
    /// `||`
    #[token("||")]
    OrOr,
    
    /// `!`
    #[token("!")]
    Bang,
    
    // ============================================================
    // OPERATORS - Bitwise
    // ============================================================
    
    /// `&` - Also used for shared reference
    #[token("&")]
    Amp,
    
    /// `|` - Also used for refinement predicates
    #[token("|")]
    Pipe,
    
    /// `~`
    #[token("~")]
    Tilde,
    
    /// `<<`
    #[token("<<")]
    Shl,
    
    /// `>>`
    #[token(">>")]
    Shr,
    
    // ============================================================
    // OPERATORS - Special
    // ============================================================
    
    /// `&!` - Exclusive reference
    #[token("&!")]
    AmpBang,
    
    /// `->`
    #[token("->")]
    Arrow,
    
    /// `=>`
    #[token("=>")]
    FatArrow,
    
    /// `=`
    #[token("=")]
    Eq,
    
    /// `::`
    #[token("::")]
    ColonColon,
    
    /// `:`
    #[token(":")]
    Colon,
    
    /// `;`
    #[token(";")]
    Semi,
    
    /// `,`
    #[token(",")]
    Comma,
    
    /// `.`
    #[token(".")]
    Dot,
    
    /// `..`
    #[token("..")]
    DotDot,
    
    /// `...`
    #[token("...")]
    DotDotDot,
    
    /// `@`
    #[token("@")]
    At,
    
    /// `#`
    #[token("#")]
    Hash,
    
    /// `?`
    #[token("?")]
    Question,
    
    /// `_`
    #[token("_")]
    Underscore,
    
    // ============================================================
    // DELIMITERS
    // ============================================================
    
    /// `(`
    #[token("(")]
    LParen,
    
    /// `)`
    #[token(")")]
    RParen,
    
    /// `[`
    #[token("[")]
    LBracket,
    
    /// `]`
    #[token("]")]
    RBracket,
    
    /// `{`
    #[token("{")]
    LBrace,
    
    /// `}`
    #[token("}")]
    RBrace,
    
    // ============================================================
    // LITERALS
    // ============================================================
    
    /// Integer literal: `42`, `0xFF`, `0b1010`, `0o77`
    #[regex(r"0[xX][0-9a-fA-F][0-9a-fA-F_]*", |lex| i64::from_str_radix(&lex.slice()[2..].replace('_', ""), 16).ok())]
    #[regex(r"0[bB][01][01_]*", |lex| i64::from_str_radix(&lex.slice()[2..].replace('_', ""), 2).ok())]
    #[regex(r"0[oO][0-7][0-7_]*", |lex| i64::from_str_radix(&lex.slice()[2..].replace('_', ""), 8).ok())]
    #[regex(r"[0-9][0-9_]*", |lex| lex.slice().replace('_', "").parse::<i64>().ok(), priority = 2)]
    IntLit(i64),
    
    /// Float literal: `3.14`, `1e10`, `2.5e-3`
    #[regex(r"[0-9][0-9_]*\.[0-9][0-9_]*([eE][+-]?[0-9]+)?", |lex| lex.slice().replace('_', "").parse::<f64>().ok())]
    #[regex(r"[0-9][0-9_]*[eE][+-]?[0-9]+", |lex| lex.slice().replace('_', "").parse::<f64>().ok())]
    FloatLit(f64),
    
    /// Unit-annotated literal: `500.0_mg`, `10_mL`, `1.5_hours`
    #[regex(r"[0-9][0-9_]*\.[0-9][0-9_]*_[a-zA-Z][a-zA-Z0-9_/]*", parse_unit_lit)]
    #[regex(r"[0-9][0-9_]*_[a-zA-Z][a-zA-Z0-9_/]*", parse_unit_lit_int)]
    UnitLit { value: f64, unit: String },
    
    /// String literal
    #[regex(r#""([^"\\]|\\.)*""#, |lex| {
        let s = lex.slice();
        Some(s[1..s.len()-1].to_string())
    })]
    StringLit(String),
    
    /// Character literal
    #[regex(r"'([^'\\]|\\.)'", |lex| {
        let s = lex.slice();
        s[1..s.len()-1].chars().next()
    })]
    CharLit(char),
    
    // ============================================================
    // IDENTIFIERS
    // ============================================================
    
    /// Identifier: starts with letter or underscore
    #[regex(r"[a-zA-Z_][a-zA-Z0-9_]*", |lex| lex.slice().to_string(), priority = 1)]
    Ident(String),
    
    // ============================================================
    // SPECIAL
    // ============================================================
    
    /// End of file
    Eof,
    
    /// Lexer error
    Error,
}

/// Parse unit-annotated float literal
fn parse_unit_lit(lex: &mut logos::Lexer<TokenKind>) -> Option<(f64, String)> {
    let s = lex.slice();
    let parts: Vec<&str> = s.splitn(2, '_').collect();
    if parts.len() == 2 {
        let value = parts[0].replace('_', "").parse::<f64>().ok()?;
        let unit = parts[1].to_string();
        Some((value, unit))
    } else {
        None
    }
}

/// Parse unit-annotated integer literal
fn parse_unit_lit_int(lex: &mut logos::Lexer<TokenKind>) -> Option<(f64, String)> {
    let s = lex.slice();
    // Find the underscore that starts the unit (skip numeric underscores)
    let mut last_numeric_end = 0;
    for (i, c) in s.char_indices() {
        if c.is_ascii_digit() || (c == '_' && i > 0 && s[..i].chars().last().map(|c| c.is_ascii_digit()).unwrap_or(false)) {
            last_numeric_end = i + 1;
        } else {
            break;
        }
    }
    
    if last_numeric_end < s.len() && s[last_numeric_end..].starts_with('_') {
        let value_str = &s[..last_numeric_end];
        let unit = &s[last_numeric_end + 1..];
        let value = value_str.replace('_', "").parse::<f64>().ok()?;
        Some((value, unit.to_string()))
    } else {
        None
    }
}

impl TokenKind {
    /// Get display name for token kind
    pub fn name(&self) -> &'static str {
        match self {
            TokenKind::Let => "let",
            TokenKind::Var => "var",
            TokenKind::Const => "const",
            TokenKind::Fn => "fn",
            TokenKind::Kernel => "kernel",
            TokenKind::Return => "return",
            TokenKind::If => "if",
            TokenKind::Else => "else",
            TokenKind::Match => "match",
            TokenKind::For => "for",
            TokenKind::While => "while",
            TokenKind::Loop => "loop",
            TokenKind::Break => "break",
            TokenKind::Continue => "continue",
            TokenKind::Struct => "struct",
            TokenKind::Enum => "enum",
            TokenKind::Type => "type",
            TokenKind::Trait => "trait",
            TokenKind::Impl => "impl",
            TokenKind::Linear => "linear",
            TokenKind::Affine => "affine",
            TokenKind::Own => "own",
            TokenKind::Module => "module",
            TokenKind::Import => "import",
            TokenKind::Export => "export",
            TokenKind::From => "from",
            TokenKind::Pub => "pub",
            TokenKind::Effect => "effect",
            TokenKind::Handle => "handle",
            TokenKind::With => "with",
            TokenKind::On => "on",
            TokenKind::Resume => "resume",
            TokenKind::Perform => "perform",
            TokenKind::Where => "where",
            TokenKind::As => "as",
            TokenKind::In => "in",
            TokenKind::Mut => "mut",
            TokenKind::Unsafe => "unsafe",
            TokenKind::True => "true",
            TokenKind::False => "false",
            TokenKind::EffectIO => "IO",
            TokenKind::EffectMut => "Mut",
            TokenKind::EffectAlloc => "Alloc",
            TokenKind::EffectPanic => "Panic",
            TokenKind::EffectAsync => "Async",
            TokenKind::EffectGPU => "GPU",
            TokenKind::EffectProb => "Prob",
            TokenKind::EffectDiv => "Div",
            TokenKind::Plus => "+",
            TokenKind::Minus => "-",
            TokenKind::Star => "*",
            TokenKind::Slash => "/",
            TokenKind::Percent => "%",
            TokenKind::Caret => "^",
            TokenKind::EqEq => "==",
            TokenKind::BangEq => "!=",
            TokenKind::Lt => "<",
            TokenKind::Le => "<=",
            TokenKind::Gt => ">",
            TokenKind::Ge => ">=",
            TokenKind::AndAnd => "&&",
            TokenKind::OrOr => "||",
            TokenKind::Bang => "!",
            TokenKind::Amp => "&",
            TokenKind::Pipe => "|",
            TokenKind::Tilde => "~",
            TokenKind::Shl => "<<",
            TokenKind::Shr => ">>",
            TokenKind::AmpBang => "&!",
            TokenKind::Arrow => "->",
            TokenKind::FatArrow => "=>",
            TokenKind::Eq => "=",
            TokenKind::ColonColon => "::",
            TokenKind::Colon => ":",
            TokenKind::Semi => ";",
            TokenKind::Comma => ",",
            TokenKind::Dot => ".",
            TokenKind::DotDot => "..",
            TokenKind::DotDotDot => "...",
            TokenKind::At => "@",
            TokenKind::Hash => "#",
            TokenKind::Question => "?",
            TokenKind::Underscore => "_",
            TokenKind::LParen => "(",
            TokenKind::RParen => ")",
            TokenKind::LBracket => "[",
            TokenKind::RBracket => "]",
            TokenKind::LBrace => "{",
            TokenKind::RBrace => "}",
            TokenKind::IntLit(_) => "integer literal",
            TokenKind::FloatLit(_) => "float literal",
            TokenKind::UnitLit { .. } => "unit literal",
            TokenKind::StringLit(_) => "string literal",
            TokenKind::CharLit(_) => "char literal",
            TokenKind::Ident(_) => "identifier",
            TokenKind::Eof => "end of file",
            TokenKind::Error => "error",
            TokenKind::TyInt => "int",
            TokenKind::TyI8 => "i8",
            TokenKind::TyI16 => "i16",
            TokenKind::TyI32 => "i32",
            TokenKind::TyI64 => "i64",
            TokenKind::TyI128 => "i128",
            TokenKind::TyUint => "uint",
            TokenKind::TyU8 => "u8",
            TokenKind::TyU16 => "u16",
            TokenKind::TyU32 => "u32",
            TokenKind::TyU64 => "u64",
            TokenKind::TyU128 => "u128",
            TokenKind::TyF32 => "f32",
            TokenKind::TyF64 => "f64",
            TokenKind::TyBool => "bool",
            TokenKind::TyChar => "char",
            TokenKind::TyString => "string",
        }
    }
}
