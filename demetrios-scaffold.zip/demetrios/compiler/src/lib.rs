//! # Demetrios (D) Programming Language
//!
//! A novel L0 systems + scientific language designed by Demetrios Chiuratto Agourakis.
//!
//! ## Features
//!
//! - **Novel Syntax**: Purpose-designed for scientific and medical computing
//! - **Full Algebraic Effects**: IO, Mut, Alloc, GPU, Prob with handlers
//! - **Linear/Affine Types**: Resource management without garbage collection
//! - **Units of Measure**: Compile-time dimensional analysis
//! - **Refinement Types**: SMT-backed constraint verification
//! - **GPU-Native**: First-class GPU memory and kernels
//! - **MLIR Integration**: Multi-level IR for optimization
//!
//! ## Compiler Pipeline
//!
//! ```text
//! Source → Lexer → Parser → AST → Type Checker → HIR → HLIR → MLIR → LLVM/GPU
//! ```
//!
//! ## Example
//!
//! ```d
//! module example
//!
//! // Units of measure
//! let dose: mg = 500.0
//! let volume: mL = 10.0
//! let concentration: mg/mL = dose / volume
//!
//! // Function with effects
//! fn read_data(path: string) -> Vec<f64> with IO, Alloc {
//!     // ...
//! }
//!
//! // Linear type for GPU memory
//! fn gpu_compute() with GPU {
//!     let buffer = gpu.alloc::<f32>(1024)  // Linear: must be freed
//!     gpu.launch(kernel, grid: (32,), block: (32,), args: (buffer,))
//!     gpu.free(buffer)
//! }
//! ```

#![allow(dead_code)]
#![allow(unused_variables)]
#![allow(unused_imports)]

pub mod lexer;
pub mod parser;
pub mod ast;
pub mod hir;
pub mod hlir;
pub mod types;
pub mod check;
pub mod effects;
pub mod mlir;
pub mod codegen;

/// Common types used across the compiler
pub mod common {
    use std::ops::Range;
    
    /// Source span for error reporting
    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
    pub struct Span {
        pub start: u32,
        pub end: u32,
    }
    
    impl Span {
        pub fn new(start: u32, end: u32) -> Self {
            Self { start, end }
        }
        
        pub fn dummy() -> Self {
            Self { start: 0, end: 0 }
        }
        
        pub fn merge(self, other: Self) -> Self {
            Self {
                start: self.start.min(other.start),
                end: self.end.max(other.end),
            }
        }
        
        pub fn to_range(self) -> Range<usize> {
            self.start as usize..self.end as usize
        }
    }
    
    impl From<Range<usize>> for Span {
        fn from(range: Range<usize>) -> Self {
            Self {
                start: range.start as u32,
                end: range.end as u32,
            }
        }
    }
    
    /// Interned string identifier
    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    pub struct Symbol(pub u32);
    
    impl Symbol {
        pub const DUMMY: Symbol = Symbol(u32::MAX);
    }
    
    /// Node ID for AST/HIR nodes
    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    pub struct NodeId(pub u32);
    
    impl NodeId {
        pub const DUMMY: NodeId = NodeId(u32::MAX);
        
        pub fn next(&self) -> NodeId {
            NodeId(self.0 + 1)
        }
    }
    
    /// Identifier with span
    #[derive(Debug, Clone, PartialEq, Eq)]
    pub struct Ident {
        pub name: Symbol,
        pub span: Span,
    }
    
    impl Ident {
        pub fn new(name: Symbol, span: Span) -> Self {
            Self { name, span }
        }
        
        pub fn dummy(name: Symbol) -> Self {
            Self { name, span: Span::dummy() }
        }
    }
}

/// Re-export common types
pub use common::{Span, Symbol, NodeId, Ident};

/// Compiler session holding global state
pub struct Session {
    /// String interner for symbols
    pub interner: string_interner::DefaultStringInterner,
    
    /// Source files
    pub sources: Vec<Source>,
    
    /// Diagnostic messages
    pub diagnostics: Vec<Diagnostic>,
}

/// A source file
pub struct Source {
    pub name: String,
    pub content: String,
}

/// A diagnostic message
#[derive(Debug)]
pub struct Diagnostic {
    pub level: DiagnosticLevel,
    pub message: String,
    pub span: Option<Span>,
    pub notes: Vec<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DiagnosticLevel {
    Error,
    Warning,
    Note,
    Help,
}

impl Session {
    pub fn new() -> Self {
        Self {
            interner: string_interner::DefaultStringInterner::new(),
            sources: Vec::new(),
            diagnostics: Vec::new(),
        }
    }
    
    pub fn intern(&mut self, s: &str) -> Symbol {
        Symbol(self.interner.get_or_intern(s).to_usize() as u32)
    }
    
    pub fn resolve(&self, sym: Symbol) -> Option<&str> {
        self.interner.resolve(string_interner::DefaultSymbol::try_from_usize(sym.0 as usize)?)
    }
    
    pub fn add_source(&mut self, name: String, content: String) -> usize {
        let idx = self.sources.len();
        self.sources.push(Source { name, content });
        idx
    }
    
    pub fn error(&mut self, message: impl Into<String>, span: Option<Span>) {
        self.diagnostics.push(Diagnostic {
            level: DiagnosticLevel::Error,
            message: message.into(),
            span,
            notes: Vec::new(),
        });
    }
    
    pub fn warning(&mut self, message: impl Into<String>, span: Option<Span>) {
        self.diagnostics.push(Diagnostic {
            level: DiagnosticLevel::Warning,
            message: message.into(),
            span,
            notes: Vec::new(),
        });
    }
    
    pub fn has_errors(&self) -> bool {
        self.diagnostics.iter().any(|d| d.level == DiagnosticLevel::Error)
    }
}

impl Default for Session {
    fn default() -> Self {
        Self::new()
    }
}
