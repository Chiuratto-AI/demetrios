//! Demetrios (D) Compiler - CLI Entry Point
//!
//! dc - The Demetrios compiler
//!
//! Usage:
//!   dc compile <file.d>     Compile to native binary
//!   dc check <file.d>       Type check without codegen
//!   dc run <file.d>         JIT compile and run
//!   dc repl                 Interactive REPL
//!   dc fmt <file.d>         Format source code

use clap::{Parser, Subcommand};
use miette::Result;
use std::path::PathBuf;

#[derive(Parser)]
#[command(name = "dc")]
#[command(author = "Demetrios Chiuratto Agourakis")]
#[command(version = "0.1.0")]
#[command(about = "The Demetrios (D) Programming Language Compiler", long_about = None)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
    
    /// Enable verbose output
    #[arg(short, long, global = true)]
    verbose: bool,
}

#[derive(Subcommand)]
enum Commands {
    /// Compile D source to native binary
    Compile {
        /// Input file
        #[arg(value_name = "FILE")]
        input: PathBuf,
        
        /// Output file
        #[arg(short, long)]
        output: Option<PathBuf>,
        
        /// Optimization level (0-3)
        #[arg(short = 'O', long, default_value = "2")]
        opt_level: u8,
        
        /// Target triple (e.g., x86_64-unknown-linux-gnu)
        #[arg(long)]
        target: Option<String>,
        
        /// Enable GPU codegen
        #[arg(long)]
        gpu: bool,
        
        /// Emit LLVM IR
        #[arg(long)]
        emit_llvm: bool,
        
        /// Emit MLIR
        #[arg(long)]
        emit_mlir: bool,
    },
    
    /// Type check without generating code
    Check {
        /// Input file
        #[arg(value_name = "FILE")]
        input: PathBuf,
        
        /// Show inferred types
        #[arg(long)]
        show_types: bool,
        
        /// Show inferred effects
        #[arg(long)]
        show_effects: bool,
    },
    
    /// JIT compile and run
    Run {
        /// Input file
        #[arg(value_name = "FILE")]
        input: PathBuf,
        
        /// Arguments to pass to the program
        #[arg(trailing_var_arg = true)]
        args: Vec<String>,
    },
    
    /// Interactive REPL
    Repl {
        /// Prelude file to load
        #[arg(long)]
        prelude: Option<PathBuf>,
    },
    
    /// Format source code
    Fmt {
        /// Input file (or directory)
        #[arg(value_name = "PATH")]
        input: PathBuf,
        
        /// Check formatting without modifying
        #[arg(long)]
        check: bool,
    },
    
    /// Language server (LSP)
    Lsp,
    
    /// Print version and build info
    Version,
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    
    match cli.command {
        Commands::Compile { input, output, opt_level, target, gpu, emit_llvm, emit_mlir } => {
            if cli.verbose {
                eprintln!("Compiling: {}", input.display());
            }
            compile(&input, output.as_deref(), opt_level, target.as_deref(), gpu, emit_llvm, emit_mlir)
        }
        Commands::Check { input, show_types, show_effects } => {
            if cli.verbose {
                eprintln!("Checking: {}", input.display());
            }
            check(&input, show_types, show_effects)
        }
        Commands::Run { input, args } => {
            if cli.verbose {
                eprintln!("Running: {}", input.display());
            }
            run(&input, &args)
        }
        Commands::Repl { prelude } => {
            repl(prelude.as_deref())
        }
        Commands::Fmt { input, check } => {
            format(&input, check)
        }
        Commands::Lsp => {
            lsp()
        }
        Commands::Version => {
            print_version();
            Ok(())
        }
    }
}

fn compile(
    input: &PathBuf,
    output: Option<&std::path::Path>,
    opt_level: u8,
    target: Option<&str>,
    gpu: bool,
    emit_llvm: bool,
    emit_mlir: bool,
) -> Result<()> {
    use demetrios::*;
    
    // Read source
    let source = std::fs::read_to_string(input)
        .map_err(|e| miette::miette!("Failed to read {}: {}", input.display(), e))?;
    
    // Lex
    let tokens = lexer::lex(&source)?;
    
    // Parse
    let ast = parser::parse(&tokens)?;
    
    // Type check
    let hir = check::check(&ast)?;
    
    // Lower to HLIR
    let hlir = hlir::lower(&hir)?;
    
    // TODO: MLIR lowering
    if emit_mlir {
        eprintln!("MLIR emission not yet implemented");
    }
    
    // TODO: LLVM codegen
    if emit_llvm {
        eprintln!("LLVM emission not yet implemented");
    }
    
    // TODO: GPU codegen
    if gpu {
        eprintln!("GPU codegen not yet implemented");
    }
    
    let _ = (output, opt_level, target);
    
    eprintln!("Compilation pipeline not yet complete");
    Ok(())
}

fn check(input: &PathBuf, show_types: bool, show_effects: bool) -> Result<()> {
    use demetrios::*;
    
    let source = std::fs::read_to_string(input)
        .map_err(|e| miette::miette!("Failed to read {}: {}", input.display(), e))?;
    
    let tokens = lexer::lex(&source)?;
    let ast = parser::parse(&tokens)?;
    let hir = check::check(&ast)?;
    
    if show_types {
        eprintln!("Type information:");
        // TODO: Print inferred types
    }
    
    if show_effects {
        eprintln!("Effect information:");
        // TODO: Print inferred effects
    }
    
    let _ = hir;
    eprintln!("✓ Type check passed");
    Ok(())
}

fn run(input: &PathBuf, args: &[String]) -> Result<()> {
    eprintln!("JIT execution not yet implemented");
    eprintln!("Would run: {} with args: {:?}", input.display(), args);
    Ok(())
}

fn repl(prelude: Option<&std::path::Path>) -> Result<()> {
    eprintln!("REPL not yet implemented");
    if let Some(p) = prelude {
        eprintln!("Would load prelude: {}", p.display());
    }
    Ok(())
}

fn format(input: &PathBuf, check: bool) -> Result<()> {
    eprintln!("Formatter not yet implemented");
    eprintln!("Would format: {} (check={})", input.display(), check);
    Ok(())
}

fn lsp() -> Result<()> {
    eprintln!("LSP server not yet implemented");
    Ok(())
}

fn print_version() {
    println!("Demetrios (D) Compiler");
    println!("Version: {}", env!("CARGO_PKG_VERSION"));
    println!("Author: Demetrios Chiuratto Agourakis");
    println!();
    println!("Features:");
    println!("  - Novel L0 systems + scientific language");
    println!("  - Full algebraic effect system");
    println!("  - Linear and affine types");
    println!("  - Units of measure");
    println!("  - Refinement types (SMT-backed)");
    println!("  - GPU-native support");
    println!();
    println!("Build info:");
    #[cfg(feature = "smt")]
    println!("  [x] SMT (Z3)");
    #[cfg(not(feature = "smt"))]
    println!("  [ ] SMT (Z3)");
    #[cfg(feature = "mlir")]
    println!("  [x] MLIR");
    #[cfg(not(feature = "mlir"))]
    println!("  [ ] MLIR");
    #[cfg(feature = "llvm")]
    println!("  [x] LLVM");
    #[cfg(not(feature = "llvm"))]
    println!("  [ ] LLVM");
    #[cfg(feature = "jit")]
    println!("  [x] JIT (Cranelift)");
    #[cfg(not(feature = "jit"))]
    println!("  [ ] JIT (Cranelift)");
    #[cfg(feature = "gpu")]
    println!("  [x] GPU");
    #[cfg(not(feature = "gpu"))]
    println!("  [ ] GPU");
}
