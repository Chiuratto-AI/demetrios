//! # Demetrios Parser
//!
//! Recursive descent parser for the D programming language.
//!
//! ## Grammar Overview
//!
//! ```text
//! program     := item*
//! item        := module | import | fn_def | struct_def | enum_def | type_alias | effect_def | const_def
//! fn_def      := "fn" IDENT generics? "(" params? ")" ("->" type)? effects? block
//! kernel_def  := "kernel" "fn" IDENT "(" params? ")" block
//! struct_def  := modifiers? "struct" IDENT generics? "{" fields "}"
//! enum_def    := "enum" IDENT generics? "{" variants "}"
//! type_alias  := "type" IDENT generics? "=" type
//! effect_def  := "effect" IDENT "{" effect_ops "}"
//! effects     := "with" effect ("," effect)*
//! ```

use crate::ast::*;
use crate::lexer::{Token, TokenKind};
use crate::common::{Span, Ident, Symbol, NodeId};
use miette::Result;

/// Parse tokens into an AST
pub fn parse(tokens: &[Token]) -> Result<Ast> {
    let mut parser = Parser::new(tokens);
    parser.parse_program()
}

/// Parser state
pub struct Parser<'a> {
    tokens: &'a [Token],
    pos: usize,
    node_id: NodeId,
}

impl<'a> Parser<'a> {
    pub fn new(tokens: &'a [Token]) -> Self {
        Self {
            tokens,
            pos: 0,
            node_id: NodeId(0),
        }
    }
    
    // ================================================================
    // UTILITY METHODS
    // ================================================================
    
    fn next_node_id(&mut self) -> NodeId {
        let id = self.node_id;
        self.node_id = self.node_id.next();
        id
    }
    
    fn current(&self) -> &Token {
        self.tokens.get(self.pos).unwrap_or(&Token {
            kind: TokenKind::Eof,
            span: Span::dummy(),
        })
    }
    
    fn peek(&self, offset: usize) -> &Token {
        self.tokens.get(self.pos + offset).unwrap_or(&Token {
            kind: TokenKind::Eof,
            span: Span::dummy(),
        })
    }
    
    fn advance(&mut self) -> &Token {
        let tok = self.current();
        if self.pos < self.tokens.len() {
            self.pos += 1;
        }
        // Return reference to previous token
        &self.tokens[self.pos - 1]
    }
    
    fn check(&self, kind: TokenKind) -> bool {
        std::mem::discriminant(&self.current().kind) == std::mem::discriminant(&kind)
    }
    
    fn at_end(&self) -> bool {
        self.check(TokenKind::Eof)
    }
    
    fn expect(&mut self, kind: TokenKind) -> Result<&Token> {
        if self.check(kind.clone()) {
            Ok(self.advance())
        } else {
            Err(miette::miette!(
                "Expected {}, found {} at {:?}",
                kind.name(),
                self.current().kind.name(),
                self.current().span
            ))
        }
    }
    
    fn consume(&mut self, kind: TokenKind) -> bool {
        if self.check(kind) {
            self.advance();
            true
        } else {
            false
        }
    }
    
    fn expect_ident(&mut self) -> Result<Ident> {
        match &self.current().kind {
            TokenKind::Ident(name) => {
                let span = self.current().span;
                let name = name.clone();
                self.advance();
                Ok(Ident {
                    name: Symbol(0), // TODO: Intern properly
                    span,
                })
            }
            _ => Err(miette::miette!(
                "Expected identifier, found {} at {:?}",
                self.current().kind.name(),
                self.current().span
            )),
        }
    }
    
    // ================================================================
    // TOP-LEVEL PARSING
    // ================================================================
    
    pub fn parse_program(&mut self) -> Result<Ast> {
        let mut items = Vec::new();
        
        while !self.at_end() {
            items.push(self.parse_item()?);
        }
        
        Ok(Ast { items })
    }
    
    fn parse_item(&mut self) -> Result<Item> {
        // Parse visibility
        let vis = if self.consume(TokenKind::Pub) {
            Visibility::Public
        } else {
            Visibility::Private
        };
        
        // Parse modifiers (linear, affine)
        let modifiers = self.parse_modifiers();
        
        match &self.current().kind {
            TokenKind::Module => self.parse_module(),
            TokenKind::Import => self.parse_import(),
            TokenKind::From => self.parse_from_import(),
            TokenKind::Fn => self.parse_fn(vis, modifiers),
            TokenKind::Kernel => self.parse_kernel(),
            TokenKind::Struct => self.parse_struct(vis, modifiers),
            TokenKind::Enum => self.parse_enum(vis),
            TokenKind::Type => self.parse_type_alias(vis),
            TokenKind::Effect => self.parse_effect(vis),
            TokenKind::Const => self.parse_const(vis),
            TokenKind::Let => self.parse_top_level_let(),
            _ => Err(miette::miette!(
                "Expected item, found {} at {:?}",
                self.current().kind.name(),
                self.current().span
            )),
        }
    }
    
    fn parse_modifiers(&mut self) -> TypeModifiers {
        let mut mods = TypeModifiers::default();
        
        loop {
            match &self.current().kind {
                TokenKind::Linear => {
                    self.advance();
                    mods.linear = true;
                }
                TokenKind::Affine => {
                    self.advance();
                    mods.affine = true;
                }
                _ => break,
            }
        }
        
        mods
    }
    
    // ================================================================
    // DECLARATIONS
    // ================================================================
    
    fn parse_module(&mut self) -> Result<Item> {
        let start = self.current().span;
        self.expect(TokenKind::Module)?;
        
        let mut path = vec![self.expect_ident()?];
        while self.consume(TokenKind::Dot) {
            path.push(self.expect_ident()?);
        }
        
        Ok(Item::Module(ModuleDef {
            id: self.next_node_id(),
            path,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_import(&mut self) -> Result<Item> {
        let start = self.current().span;
        self.expect(TokenKind::Import)?;
        
        let mut path = vec![self.expect_ident()?];
        while self.consume(TokenKind::Dot) {
            path.push(self.expect_ident()?);
        }
        
        Ok(Item::Import(ImportDef {
            id: self.next_node_id(),
            path,
            items: None,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_from_import(&mut self) -> Result<Item> {
        let start = self.current().span;
        self.expect(TokenKind::From)?;
        
        let mut path = vec![self.expect_ident()?];
        while self.consume(TokenKind::Dot) {
            path.push(self.expect_ident()?);
        }
        
        self.expect(TokenKind::Import)?;
        self.expect(TokenKind::LBrace)?;
        
        let mut items = vec![self.expect_ident()?];
        while self.consume(TokenKind::Comma) {
            if self.check(TokenKind::RBrace) {
                break;
            }
            items.push(self.expect_ident()?);
        }
        
        self.expect(TokenKind::RBrace)?;
        
        Ok(Item::Import(ImportDef {
            id: self.next_node_id(),
            path,
            items: Some(items),
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_fn(&mut self, vis: Visibility, modifiers: TypeModifiers) -> Result<Item> {
        let start = self.current().span;
        self.expect(TokenKind::Fn)?;
        
        let name = self.expect_ident()?;
        let generics = self.parse_generics()?;
        
        self.expect(TokenKind::LParen)?;
        let params = self.parse_params()?;
        self.expect(TokenKind::RParen)?;
        
        let return_type = if self.consume(TokenKind::Arrow) {
            Some(Box::new(self.parse_type()?))
        } else {
            None
        };
        
        let effects = self.parse_effects()?;
        let body = self.parse_block()?;
        
        Ok(Item::Function(FnDef {
            id: self.next_node_id(),
            vis,
            modifiers,
            name,
            generics,
            params,
            return_type,
            effects,
            body,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_kernel(&mut self) -> Result<Item> {
        let start = self.current().span;
        self.expect(TokenKind::Kernel)?;
        self.expect(TokenKind::Fn)?;
        
        let name = self.expect_ident()?;
        
        self.expect(TokenKind::LParen)?;
        let params = self.parse_params()?;
        self.expect(TokenKind::RParen)?;
        
        let body = self.parse_block()?;
        
        Ok(Item::Kernel(KernelDef {
            id: self.next_node_id(),
            name,
            params,
            body,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_struct(&mut self, vis: Visibility, modifiers: TypeModifiers) -> Result<Item> {
        let start = self.current().span;
        self.expect(TokenKind::Struct)?;
        
        let name = self.expect_ident()?;
        let generics = self.parse_generics()?;
        
        self.expect(TokenKind::LBrace)?;
        let fields = self.parse_fields()?;
        self.expect(TokenKind::RBrace)?;
        
        Ok(Item::Struct(StructDef {
            id: self.next_node_id(),
            vis,
            modifiers,
            name,
            generics,
            fields,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_enum(&mut self, vis: Visibility) -> Result<Item> {
        let start = self.current().span;
        self.expect(TokenKind::Enum)?;
        
        let name = self.expect_ident()?;
        let generics = self.parse_generics()?;
        
        self.expect(TokenKind::LBrace)?;
        let variants = self.parse_variants()?;
        self.expect(TokenKind::RBrace)?;
        
        Ok(Item::Enum(EnumDef {
            id: self.next_node_id(),
            vis,
            name,
            generics,
            variants,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_type_alias(&mut self, vis: Visibility) -> Result<Item> {
        let start = self.current().span;
        self.expect(TokenKind::Type)?;
        
        let name = self.expect_ident()?;
        let generics = self.parse_generics()?;
        
        self.expect(TokenKind::Eq)?;
        let ty = self.parse_type()?;
        
        Ok(Item::TypeAlias(TypeAliasDef {
            id: self.next_node_id(),
            vis,
            name,
            generics,
            ty: Box::new(ty),
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_effect(&mut self, vis: Visibility) -> Result<Item> {
        let start = self.current().span;
        self.expect(TokenKind::Effect)?;
        
        let name = self.expect_ident()?;
        
        self.expect(TokenKind::LBrace)?;
        let mut ops = Vec::new();
        
        while !self.check(TokenKind::RBrace) && !self.at_end() {
            ops.push(self.parse_effect_op()?);
        }
        
        self.expect(TokenKind::RBrace)?;
        
        Ok(Item::Effect(EffectDef {
            id: self.next_node_id(),
            vis,
            name,
            ops,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_effect_op(&mut self) -> Result<EffectOp> {
        let start = self.current().span;
        self.expect(TokenKind::Fn)?;
        
        let name = self.expect_ident()?;
        
        self.expect(TokenKind::LParen)?;
        let params = self.parse_params()?;
        self.expect(TokenKind::RParen)?;
        
        let return_type = if self.consume(TokenKind::Arrow) {
            Some(Box::new(self.parse_type()?))
        } else {
            None
        };
        
        Ok(EffectOp {
            id: self.next_node_id(),
            name,
            params,
            return_type,
            span: start.merge(self.peek(0).span),
        })
    }
    
    fn parse_const(&mut self, vis: Visibility) -> Result<Item> {
        let start = self.current().span;
        self.expect(TokenKind::Const)?;
        
        let name = self.expect_ident()?;
        
        let ty = if self.consume(TokenKind::Colon) {
            Some(Box::new(self.parse_type()?))
        } else {
            None
        };
        
        self.expect(TokenKind::Eq)?;
        let value = self.parse_expr()?;
        
        Ok(Item::Const(ConstDef {
            id: self.next_node_id(),
            vis,
            name,
            ty,
            value: Box::new(value),
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_top_level_let(&mut self) -> Result<Item> {
        // For now, treat as a statement wrapped in an item
        let stmt = self.parse_let_stmt()?;
        Ok(Item::Stmt(stmt))
    }
    
    // ================================================================
    // GENERICS AND PARAMS
    // ================================================================
    
    fn parse_generics(&mut self) -> Result<Vec<GenericParam>> {
        if !self.consume(TokenKind::Lt) {
            return Ok(Vec::new());
        }
        
        let mut params = Vec::new();
        
        loop {
            let name = self.expect_ident()?;
            let bounds = if self.consume(TokenKind::Colon) {
                self.parse_type_bounds()?
            } else {
                Vec::new()
            };
            
            params.push(GenericParam {
                id: self.next_node_id(),
                name,
                bounds,
            });
            
            if !self.consume(TokenKind::Comma) {
                break;
            }
        }
        
        self.expect(TokenKind::Gt)?;
        Ok(params)
    }
    
    fn parse_type_bounds(&mut self) -> Result<Vec<TypeBound>> {
        let mut bounds = Vec::new();
        
        loop {
            let path = self.parse_path()?;
            bounds.push(TypeBound::Trait(path));
            
            if !self.consume(TokenKind::Plus) {
                break;
            }
        }
        
        Ok(bounds)
    }
    
    fn parse_params(&mut self) -> Result<Vec<Param>> {
        let mut params = Vec::new();
        
        if self.check(TokenKind::RParen) {
            return Ok(params);
        }
        
        loop {
            let name = self.expect_ident()?;
            self.expect(TokenKind::Colon)?;
            let ty = self.parse_type()?;
            
            params.push(Param {
                id: self.next_node_id(),
                name,
                ty: Box::new(ty),
            });
            
            if !self.consume(TokenKind::Comma) {
                break;
            }
        }
        
        Ok(params)
    }
    
    fn parse_fields(&mut self) -> Result<Vec<Field>> {
        let mut fields = Vec::new();
        
        while !self.check(TokenKind::RBrace) && !self.at_end() {
            let name = self.expect_ident()?;
            self.expect(TokenKind::Colon)?;
            let ty = self.parse_type()?;
            
            fields.push(Field {
                id: self.next_node_id(),
                name,
                ty: Box::new(ty),
            });
            
            self.consume(TokenKind::Comma);
        }
        
        Ok(fields)
    }
    
    fn parse_variants(&mut self) -> Result<Vec<Variant>> {
        let mut variants = Vec::new();
        
        while !self.check(TokenKind::RBrace) && !self.at_end() {
            let name = self.expect_ident()?;
            
            let fields = if self.consume(TokenKind::LParen) {
                let fields = self.parse_fields()?;
                self.expect(TokenKind::RParen)?;
                fields
            } else if self.consume(TokenKind::LBrace) {
                let fields = self.parse_fields()?;
                self.expect(TokenKind::RBrace)?;
                fields
            } else {
                Vec::new()
            };
            
            variants.push(Variant {
                id: self.next_node_id(),
                name,
                fields,
            });
            
            self.consume(TokenKind::Comma);
        }
        
        Ok(variants)
    }
    
    fn parse_effects(&mut self) -> Result<Vec<EffectRef>> {
        if !self.consume(TokenKind::With) {
            return Ok(Vec::new());
        }
        
        let mut effects = Vec::new();
        
        loop {
            let effect = self.parse_effect_ref()?;
            effects.push(effect);
            
            if !self.consume(TokenKind::Comma) {
                break;
            }
        }
        
        Ok(effects)
    }
    
    fn parse_effect_ref(&mut self) -> Result<EffectRef> {
        let span = self.current().span;
        
        match &self.current().kind {
            TokenKind::EffectIO => { self.advance(); Ok(EffectRef::IO(span)) }
            TokenKind::EffectMut => { self.advance(); Ok(EffectRef::Mut(span)) }
            TokenKind::EffectAlloc => { self.advance(); Ok(EffectRef::Alloc(span)) }
            TokenKind::EffectPanic => { self.advance(); Ok(EffectRef::Panic(span)) }
            TokenKind::EffectAsync => { self.advance(); Ok(EffectRef::Async(span)) }
            TokenKind::EffectGPU => { self.advance(); Ok(EffectRef::GPU(span)) }
            TokenKind::EffectProb => { self.advance(); Ok(EffectRef::Prob(span)) }
            TokenKind::EffectDiv => { self.advance(); Ok(EffectRef::Div(span)) }
            TokenKind::Ident(name) => {
                let ident = self.expect_ident()?;
                Ok(EffectRef::Named(ident))
            }
            _ => Err(miette::miette!(
                "Expected effect, found {} at {:?}",
                self.current().kind.name(),
                self.current().span
            )),
        }
    }
    
    // ================================================================
    // TYPES
    // ================================================================
    
    fn parse_type(&mut self) -> Result<Type> {
        self.parse_type_union()
    }
    
    fn parse_type_union(&mut self) -> Result<Type> {
        // For now, just parse primary types
        self.parse_type_primary()
    }
    
    fn parse_type_primary(&mut self) -> Result<Type> {
        let start = self.current().span;
        
        // Check for modifiers
        if self.consume(TokenKind::Linear) {
            let inner = self.parse_type_primary()?;
            return Ok(Type::Linear(Box::new(inner), start));
        }
        
        if self.consume(TokenKind::Affine) {
            let inner = self.parse_type_primary()?;
            return Ok(Type::Affine(Box::new(inner), start));
        }
        
        // Reference types
        if self.consume(TokenKind::AmpBang) {
            let inner = self.parse_type_primary()?;
            return Ok(Type::Ref(RefKind::Exclusive, Box::new(inner), None, start));
        }
        
        if self.consume(TokenKind::Amp) {
            let inner = self.parse_type_primary()?;
            return Ok(Type::Ref(RefKind::Shared, Box::new(inner), None, start));
        }
        
        if self.consume(TokenKind::Own) {
            let inner = self.parse_type_primary()?;
            return Ok(Type::Own(Box::new(inner), start));
        }
        
        // Tuple or grouped type
        if self.consume(TokenKind::LParen) {
            if self.check(TokenKind::RParen) {
                self.advance();
                return Ok(Type::Unit(start));
            }
            
            let first = self.parse_type()?;
            
            if self.consume(TokenKind::Comma) {
                let mut types = vec![first];
                loop {
                    types.push(self.parse_type()?);
                    if !self.consume(TokenKind::Comma) {
                        break;
                    }
                }
                self.expect(TokenKind::RParen)?;
                return Ok(Type::Tuple(types, start));
            }
            
            self.expect(TokenKind::RParen)?;
            return Ok(first);
        }
        
        // Array type
        if self.consume(TokenKind::LBracket) {
            let elem = self.parse_type()?;
            
            let size = if self.consume(TokenKind::Semi) {
                Some(Box::new(self.parse_expr()?))
            } else {
                None
            };
            
            self.expect(TokenKind::RBracket)?;
            
            return Ok(Type::Array(Box::new(elem), size, start));
        }
        
        // Refinement type: { x: T | pred }
        if self.consume(TokenKind::LBrace) {
            let var = self.expect_ident()?;
            self.expect(TokenKind::Colon)?;
            let base = self.parse_type()?;
            self.expect(TokenKind::Pipe)?;
            let pred = self.parse_expr()?;
            self.expect(TokenKind::RBrace)?;
            
            return Ok(Type::Refined(Box::new(base), var, Box::new(pred), start));
        }
        
        // Named type (possibly generic)
        let path = self.parse_path()?;
        
        if self.consume(TokenKind::Lt) {
            let mut args = vec![self.parse_type()?];
            while self.consume(TokenKind::Comma) {
                args.push(self.parse_type()?);
            }
            self.expect(TokenKind::Gt)?;
            return Ok(Type::Generic(path, args, start));
        }
        
        Ok(Type::Named(path, start))
    }
    
    fn parse_path(&mut self) -> Result<Path> {
        let start = self.current().span;
        let mut segments = vec![self.expect_ident()?];
        
        while self.consume(TokenKind::ColonColon) {
            segments.push(self.expect_ident()?);
        }
        
        Ok(Path {
            segments,
            span: start.merge(self.peek(0).span),
        })
    }
    
    // ================================================================
    // STATEMENTS
    // ================================================================
    
    fn parse_block(&mut self) -> Result<Block> {
        let start = self.current().span;
        self.expect(TokenKind::LBrace)?;
        
        let mut stmts = Vec::new();
        
        while !self.check(TokenKind::RBrace) && !self.at_end() {
            stmts.push(self.parse_stmt()?);
        }
        
        self.expect(TokenKind::RBrace)?;
        
        Ok(Block {
            id: self.next_node_id(),
            stmts,
            span: start.merge(self.peek(0).span),
        })
    }
    
    fn parse_stmt(&mut self) -> Result<Stmt> {
        match &self.current().kind {
            TokenKind::Let => self.parse_let_stmt(),
            TokenKind::Var => self.parse_var_stmt(),
            TokenKind::Return => self.parse_return_stmt(),
            TokenKind::If => self.parse_if_stmt(),
            TokenKind::Match => self.parse_match_stmt(),
            TokenKind::For => self.parse_for_stmt(),
            TokenKind::While => self.parse_while_stmt(),
            TokenKind::Loop => self.parse_loop_stmt(),
            TokenKind::Handle => self.parse_handle_stmt(),
            _ => self.parse_expr_stmt(),
        }
    }
    
    fn parse_let_stmt(&mut self) -> Result<Stmt> {
        let start = self.current().span;
        self.expect(TokenKind::Let)?;
        
        let name = self.expect_ident()?;
        
        let ty = if self.consume(TokenKind::Colon) {
            Some(Box::new(self.parse_type()?))
        } else {
            None
        };
        
        self.expect(TokenKind::Eq)?;
        let value = self.parse_expr()?;
        
        Ok(Stmt::Let(LetStmt {
            id: self.next_node_id(),
            mutable: false,
            name,
            ty,
            value: Box::new(value),
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_var_stmt(&mut self) -> Result<Stmt> {
        let start = self.current().span;
        self.expect(TokenKind::Var)?;
        
        let name = self.expect_ident()?;
        
        let ty = if self.consume(TokenKind::Colon) {
            Some(Box::new(self.parse_type()?))
        } else {
            None
        };
        
        self.expect(TokenKind::Eq)?;
        let value = self.parse_expr()?;
        
        Ok(Stmt::Let(LetStmt {
            id: self.next_node_id(),
            mutable: true,
            name,
            ty,
            value: Box::new(value),
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_return_stmt(&mut self) -> Result<Stmt> {
        let start = self.current().span;
        self.expect(TokenKind::Return)?;
        
        let value = if self.check(TokenKind::RBrace) || self.check(TokenKind::Semi) {
            None
        } else {
            Some(Box::new(self.parse_expr()?))
        };
        
        Ok(Stmt::Return(ReturnStmt {
            id: self.next_node_id(),
            value,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_if_stmt(&mut self) -> Result<Stmt> {
        let start = self.current().span;
        self.expect(TokenKind::If)?;
        
        let cond = self.parse_expr()?;
        let then_block = self.parse_block()?;
        
        let else_block = if self.consume(TokenKind::Else) {
            if self.check(TokenKind::If) {
                // else if
                let elif = self.parse_if_stmt()?;
                Some(Block {
                    id: self.next_node_id(),
                    stmts: vec![elif],
                    span: self.peek(0).span,
                })
            } else {
                Some(self.parse_block()?)
            }
        } else {
            None
        };
        
        Ok(Stmt::If(IfStmt {
            id: self.next_node_id(),
            cond: Box::new(cond),
            then_block,
            else_block,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_match_stmt(&mut self) -> Result<Stmt> {
        let start = self.current().span;
        self.expect(TokenKind::Match)?;
        
        let scrutinee = self.parse_expr()?;
        self.expect(TokenKind::LBrace)?;
        
        let mut arms = Vec::new();
        while !self.check(TokenKind::RBrace) && !self.at_end() {
            let pattern = self.parse_pattern()?;
            self.expect(TokenKind::FatArrow)?;
            let body = self.parse_expr()?;
            self.consume(TokenKind::Comma);
            
            arms.push(MatchArm {
                id: self.next_node_id(),
                pattern,
                body: Box::new(body),
            });
        }
        
        self.expect(TokenKind::RBrace)?;
        
        Ok(Stmt::Match(MatchStmt {
            id: self.next_node_id(),
            scrutinee: Box::new(scrutinee),
            arms,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_for_stmt(&mut self) -> Result<Stmt> {
        let start = self.current().span;
        self.expect(TokenKind::For)?;
        
        let var = self.expect_ident()?;
        self.expect(TokenKind::In)?;
        let iter = self.parse_expr()?;
        let body = self.parse_block()?;
        
        Ok(Stmt::For(ForStmt {
            id: self.next_node_id(),
            var,
            iter: Box::new(iter),
            body,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_while_stmt(&mut self) -> Result<Stmt> {
        let start = self.current().span;
        self.expect(TokenKind::While)?;
        
        let cond = self.parse_expr()?;
        let body = self.parse_block()?;
        
        Ok(Stmt::While(WhileStmt {
            id: self.next_node_id(),
            cond: Box::new(cond),
            body,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_loop_stmt(&mut self) -> Result<Stmt> {
        let start = self.current().span;
        self.expect(TokenKind::Loop)?;
        
        let body = self.parse_block()?;
        
        Ok(Stmt::Loop(LoopStmt {
            id: self.next_node_id(),
            body,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_handle_stmt(&mut self) -> Result<Stmt> {
        let start = self.current().span;
        self.expect(TokenKind::Handle)?;
        
        let name = self.expect_ident()?;
        self.expect(TokenKind::For)?;
        let effect = self.parse_effect_ref()?;
        
        self.expect(TokenKind::LBrace)?;
        
        let mut handlers = Vec::new();
        while self.consume(TokenKind::On) {
            let op = self.expect_ident()?;
            self.expect(TokenKind::LParen)?;
            let params = self.parse_params()?;
            self.expect(TokenKind::RParen)?;
            self.expect(TokenKind::Arrow)?;
            let body = self.parse_expr()?;
            
            handlers.push(HandlerCase {
                id: self.next_node_id(),
                op,
                params,
                body: Box::new(body),
            });
        }
        
        self.expect(TokenKind::RBrace)?;
        
        Ok(Stmt::Handle(HandleStmt {
            id: self.next_node_id(),
            name,
            effect,
            handlers,
            span: start.merge(self.peek(0).span),
        }))
    }
    
    fn parse_expr_stmt(&mut self) -> Result<Stmt> {
        let expr = self.parse_expr()?;
        Ok(Stmt::Expr(ExprStmt {
            id: self.next_node_id(),
            expr: Box::new(expr),
        }))
    }
    
    // ================================================================
    // PATTERNS
    // ================================================================
    
    fn parse_pattern(&mut self) -> Result<Pattern> {
        let start = self.current().span;
        
        match &self.current().kind {
            TokenKind::Underscore => {
                self.advance();
                Ok(Pattern::Wildcard(start))
            }
            TokenKind::IntLit(n) => {
                let n = *n;
                self.advance();
                Ok(Pattern::Literal(Literal::Int(n), start))
            }
            TokenKind::True => {
                self.advance();
                Ok(Pattern::Literal(Literal::Bool(true), start))
            }
            TokenKind::False => {
                self.advance();
                Ok(Pattern::Literal(Literal::Bool(false), start))
            }
            TokenKind::Ident(_) => {
                let path = self.parse_path()?;
                
                if self.consume(TokenKind::LParen) {
                    // Variant with tuple fields
                    let mut fields = Vec::new();
                    if !self.check(TokenKind::RParen) {
                        loop {
                            fields.push(self.parse_pattern()?);
                            if !self.consume(TokenKind::Comma) {
                                break;
                            }
                        }
                    }
                    self.expect(TokenKind::RParen)?;
                    Ok(Pattern::Variant(path, fields, start))
                } else if self.consume(TokenKind::LBrace) {
                    // Struct pattern
                    let mut fields = Vec::new();
                    while !self.check(TokenKind::RBrace) && !self.at_end() {
                        let name = self.expect_ident()?;
                        let pattern = if self.consume(TokenKind::Colon) {
                            self.parse_pattern()?
                        } else {
                            Pattern::Binding(name.clone(), start)
                        };
                        fields.push((name, pattern));
                        self.consume(TokenKind::Comma);
                    }
                    self.expect(TokenKind::RBrace)?;
                    Ok(Pattern::Struct(path, fields, start))
                } else if path.segments.len() == 1 {
                    // Simple binding
                    Ok(Pattern::Binding(path.segments.into_iter().next().unwrap(), start))
                } else {
                    // Enum variant without fields
                    Ok(Pattern::Variant(path, Vec::new(), start))
                }
            }
            _ => Err(miette::miette!(
                "Expected pattern, found {} at {:?}",
                self.current().kind.name(),
                self.current().span
            )),
        }
    }
    
    // ================================================================
    // EXPRESSIONS (Pratt Parser)
    // ================================================================
    
    fn parse_expr(&mut self) -> Result<Expr> {
        self.parse_expr_bp(0)
    }
    
    fn parse_expr_bp(&mut self, min_bp: u8) -> Result<Expr> {
        let mut lhs = self.parse_expr_prefix()?;
        
        loop {
            let op = match self.current().kind.clone() {
                TokenKind::Plus => BinOp::Add,
                TokenKind::Minus => BinOp::Sub,
                TokenKind::Star => BinOp::Mul,
                TokenKind::Slash => BinOp::Div,
                TokenKind::Percent => BinOp::Mod,
                TokenKind::Caret => BinOp::Pow,
                TokenKind::EqEq => BinOp::Eq,
                TokenKind::BangEq => BinOp::Ne,
                TokenKind::Lt => BinOp::Lt,
                TokenKind::Le => BinOp::Le,
                TokenKind::Gt => BinOp::Gt,
                TokenKind::Ge => BinOp::Ge,
                TokenKind::AndAnd => BinOp::And,
                TokenKind::OrOr => BinOp::Or,
                TokenKind::Eq => BinOp::Assign,
                _ => break,
            };
            
            let (l_bp, r_bp) = infix_binding_power(&op);
            if l_bp < min_bp {
                break;
            }
            
            self.advance();
            let rhs = self.parse_expr_bp(r_bp)?;
            
            let span = lhs.span().merge(rhs.span());
            lhs = Expr::Binary(BinaryExpr {
                id: self.next_node_id(),
                op,
                lhs: Box::new(lhs),
                rhs: Box::new(rhs),
                span,
            });
        }
        
        Ok(lhs)
    }
    
    fn parse_expr_prefix(&mut self) -> Result<Expr> {
        let start = self.current().span;
        
        match &self.current().kind {
            TokenKind::Minus => {
                self.advance();
                let operand = self.parse_expr_prefix()?;
                Ok(Expr::Unary(UnaryExpr {
                    id: self.next_node_id(),
                    op: UnaryOp::Neg,
                    operand: Box::new(operand),
                    span: start,
                }))
            }
            TokenKind::Bang => {
                self.advance();
                let operand = self.parse_expr_prefix()?;
                Ok(Expr::Unary(UnaryExpr {
                    id: self.next_node_id(),
                    op: UnaryOp::Not,
                    operand: Box::new(operand),
                    span: start,
                }))
            }
            TokenKind::Amp => {
                self.advance();
                let operand = self.parse_expr_prefix()?;
                Ok(Expr::Unary(UnaryExpr {
                    id: self.next_node_id(),
                    op: UnaryOp::Ref,
                    operand: Box::new(operand),
                    span: start,
                }))
            }
            TokenKind::AmpBang => {
                self.advance();
                let operand = self.parse_expr_prefix()?;
                Ok(Expr::Unary(UnaryExpr {
                    id: self.next_node_id(),
                    op: UnaryOp::RefMut,
                    operand: Box::new(operand),
                    span: start,
                }))
            }
            TokenKind::Star => {
                self.advance();
                let operand = self.parse_expr_prefix()?;
                Ok(Expr::Unary(UnaryExpr {
                    id: self.next_node_id(),
                    op: UnaryOp::Deref,
                    operand: Box::new(operand),
                    span: start,
                }))
            }
            _ => self.parse_expr_postfix(),
        }
    }
    
    fn parse_expr_postfix(&mut self) -> Result<Expr> {
        let mut expr = self.parse_expr_primary()?;
        
        loop {
            match &self.current().kind {
                TokenKind::LParen => {
                    // Function call
                    self.advance();
                    let mut args = Vec::new();
                    if !self.check(TokenKind::RParen) {
                        loop {
                            args.push(self.parse_expr()?);
                            if !self.consume(TokenKind::Comma) {
                                break;
                            }
                        }
                    }
                    let end = self.current().span;
                    self.expect(TokenKind::RParen)?;
                    
                    expr = Expr::Call(CallExpr {
                        id: self.next_node_id(),
                        callee: Box::new(expr),
                        args,
                        span: expr.span().merge(end),
                    });
                }
                TokenKind::LBracket => {
                    // Index
                    self.advance();
                    let index = self.parse_expr()?;
                    let end = self.current().span;
                    self.expect(TokenKind::RBracket)?;
                    
                    expr = Expr::Index(IndexExpr {
                        id: self.next_node_id(),
                        base: Box::new(expr),
                        index: Box::new(index),
                        span: expr.span().merge(end),
                    });
                }
                TokenKind::Dot => {
                    // Field access
                    self.advance();
                    let field = self.expect_ident()?;
                    
                    expr = Expr::Field(FieldExpr {
                        id: self.next_node_id(),
                        base: Box::new(expr),
                        field,
                        span: expr.span().merge(self.peek(0).span),
                    });
                }
                TokenKind::ColonColon => {
                    // Method call or associated function
                    self.advance();
                    let method = self.expect_ident()?;
                    
                    if self.consume(TokenKind::LParen) {
                        let mut args = Vec::new();
                        if !self.check(TokenKind::RParen) {
                            loop {
                                args.push(self.parse_expr()?);
                                if !self.consume(TokenKind::Comma) {
                                    break;
                                }
                            }
                        }
                        let end = self.current().span;
                        self.expect(TokenKind::RParen)?;
                        
                        expr = Expr::MethodCall(MethodCallExpr {
                            id: self.next_node_id(),
                            receiver: Box::new(expr),
                            method,
                            args,
                            span: expr.span().merge(end),
                        });
                    }
                }
                TokenKind::As => {
                    // Type cast
                    self.advance();
                    let ty = self.parse_type()?;
                    
                    expr = Expr::Cast(CastExpr {
                        id: self.next_node_id(),
                        expr: Box::new(expr),
                        ty: Box::new(ty),
                        span: expr.span().merge(self.peek(0).span),
                    });
                }
                _ => break,
            }
        }
        
        Ok(expr)
    }
    
    fn parse_expr_primary(&mut self) -> Result<Expr> {
        let start = self.current().span;
        
        match self.current().kind.clone() {
            TokenKind::IntLit(n) => {
                self.advance();
                Ok(Expr::Literal(LiteralExpr {
                    id: self.next_node_id(),
                    value: Literal::Int(n),
                    span: start,
                }))
            }
            TokenKind::FloatLit(f) => {
                self.advance();
                Ok(Expr::Literal(LiteralExpr {
                    id: self.next_node_id(),
                    value: Literal::Float(f),
                    span: start,
                }))
            }
            TokenKind::UnitLit { value, unit } => {
                self.advance();
                Ok(Expr::Literal(LiteralExpr {
                    id: self.next_node_id(),
                    value: Literal::UnitValue { value, unit },
                    span: start,
                }))
            }
            TokenKind::StringLit(s) => {
                self.advance();
                Ok(Expr::Literal(LiteralExpr {
                    id: self.next_node_id(),
                    value: Literal::String(s),
                    span: start,
                }))
            }
            TokenKind::CharLit(c) => {
                self.advance();
                Ok(Expr::Literal(LiteralExpr {
                    id: self.next_node_id(),
                    value: Literal::Char(c),
                    span: start,
                }))
            }
            TokenKind::True => {
                self.advance();
                Ok(Expr::Literal(LiteralExpr {
                    id: self.next_node_id(),
                    value: Literal::Bool(true),
                    span: start,
                }))
            }
            TokenKind::False => {
                self.advance();
                Ok(Expr::Literal(LiteralExpr {
                    id: self.next_node_id(),
                    value: Literal::Bool(false),
                    span: start,
                }))
            }
            TokenKind::Ident(_) => {
                let path = self.parse_path()?;
                Ok(Expr::Path(PathExpr {
                    id: self.next_node_id(),
                    path,
                    span: start,
                }))
            }
            TokenKind::LParen => {
                self.advance();
                if self.check(TokenKind::RParen) {
                    self.advance();
                    return Ok(Expr::Literal(LiteralExpr {
                        id: self.next_node_id(),
                        value: Literal::Unit,
                        span: start,
                    }));
                }
                
                let expr = self.parse_expr()?;
                
                if self.consume(TokenKind::Comma) {
                    // Tuple
                    let mut exprs = vec![expr];
                    loop {
                        exprs.push(self.parse_expr()?);
                        if !self.consume(TokenKind::Comma) {
                            break;
                        }
                    }
                    self.expect(TokenKind::RParen)?;
                    return Ok(Expr::Tuple(TupleExpr {
                        id: self.next_node_id(),
                        elements: exprs,
                        span: start.merge(self.peek(0).span),
                    }));
                }
                
                self.expect(TokenKind::RParen)?;
                Ok(expr)
            }
            TokenKind::LBracket => {
                self.advance();
                let mut elements = Vec::new();
                
                if !self.check(TokenKind::RBracket) {
                    loop {
                        elements.push(self.parse_expr()?);
                        if !self.consume(TokenKind::Comma) {
                            break;
                        }
                    }
                }
                
                self.expect(TokenKind::RBracket)?;
                Ok(Expr::Array(ArrayExpr {
                    id: self.next_node_id(),
                    elements,
                    span: start.merge(self.peek(0).span),
                }))
            }
            TokenKind::LBrace => {
                // Block expression
                let block = self.parse_block()?;
                Ok(Expr::Block(BlockExpr {
                    id: self.next_node_id(),
                    block,
                    span: start.merge(self.peek(0).span),
                }))
            }
            TokenKind::If => {
                self.advance();
                let cond = self.parse_expr()?;
                let then_block = self.parse_block()?;
                
                let else_block = if self.consume(TokenKind::Else) {
                    Some(self.parse_block()?)
                } else {
                    None
                };
                
                Ok(Expr::If(IfExpr {
                    id: self.next_node_id(),
                    cond: Box::new(cond),
                    then_block,
                    else_block,
                    span: start.merge(self.peek(0).span),
                }))
            }
            TokenKind::With => {
                // with handler { body }
                self.advance();
                let handler = self.expect_ident()?;
                let body = self.parse_block()?;
                
                Ok(Expr::With(WithExpr {
                    id: self.next_node_id(),
                    handler,
                    body,
                    span: start.merge(self.peek(0).span),
                }))
            }
            TokenKind::Resume => {
                self.advance();
                self.expect(TokenKind::LParen)?;
                let value = self.parse_expr()?;
                self.expect(TokenKind::RParen)?;
                
                Ok(Expr::Resume(ResumeExpr {
                    id: self.next_node_id(),
                    value: Box::new(value),
                    span: start.merge(self.peek(0).span),
                }))
            }
            _ => Err(miette::miette!(
                "Expected expression, found {} at {:?}",
                self.current().kind.name(),
                self.current().span
            )),
        }
    }
}

/// Get binding power for infix operators
fn infix_binding_power(op: &BinOp) -> (u8, u8) {
    match op {
        BinOp::Assign => (2, 1),
        BinOp::Or => (3, 4),
        BinOp::And => (5, 6),
        BinOp::Eq | BinOp::Ne => (7, 8),
        BinOp::Lt | BinOp::Le | BinOp::Gt | BinOp::Ge => (9, 10),
        BinOp::Add | BinOp::Sub => (11, 12),
        BinOp::Mul | BinOp::Div | BinOp::Mod => (13, 14),
        BinOp::Pow => (16, 15), // Right associative
    }
}
