//! Core type definitions

use crate::common::NodeId;
use std::collections::HashMap;

/// Core type representation
#[derive(Debug, Clone, PartialEq)]
pub enum Type {
    /// Unknown type (for inference)
    Unknown,
    
    /// Error type (for error recovery)
    Error,
    
    /// Unit type ()
    Unit,
    
    /// Boolean
    Bool,
    
    /// Signed integers
    I8, I16, I32, I64, I128,
    Int,  // Platform-sized
    
    /// Unsigned integers
    U8, U16, U32, U64, U128,
    UInt, // Platform-sized
    
    /// Floating point
    F32, F64,
    
    /// Character
    Char,
    
    /// String
    String,
    
    /// Reference types
    Ref(RefKind, Box<Type>),
    
    /// Owned type
    Own(Box<Type>),
    
    /// Linear type (must be consumed exactly once)
    Linear(Box<Type>),
    
    /// Affine type (can be consumed at most once)
    Affine(Box<Type>),
    
    /// Tuple
    Tuple(Vec<Type>),
    
    /// Array with known size
    Array(Box<Type>, usize),
    
    /// Slice (dynamically sized)
    Slice(Box<Type>),
    
    /// Named type (struct, enum, type alias)
    Named(TypeId),
    
    /// Generic instantiation
    App(TypeId, Vec<Type>),
    
    /// Type variable (for polymorphism)
    Var(TypeVar),
    
    /// Function type
    Fn(FnType),
    
    /// Refined type
    Refined(Box<Type>, RefinementPredicate),
    
    /// Unit-annotated type
    WithUnit(Box<Type>, UnitType),
}

/// Reference kind
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RefKind {
    /// Shared reference (&T)
    Shared,
    /// Exclusive reference (&!T)
    Exclusive,
}

/// Type identifier
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct TypeId(pub u32);

/// Type variable
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct TypeVar(pub u32);

/// Function type
#[derive(Debug, Clone, PartialEq)]
pub struct FnType {
    pub params: Vec<Type>,
    pub return_type: Box<Type>,
    pub effects: EffectSet,
}

/// Effect set
#[derive(Debug, Clone, PartialEq, Default)]
pub struct EffectSet {
    pub effects: Vec<Effect>,
}

/// Effect
#[derive(Debug, Clone, PartialEq)]
pub enum Effect {
    IO,
    Mut,
    Alloc,
    Panic,
    Async,
    GPU,
    Prob,
    Div,
    Named(String),
    Var(TypeVar),  // Effect variable for polymorphism
}

/// Refinement predicate
#[derive(Debug, Clone, PartialEq)]
pub struct RefinementPredicate {
    pub var: String,
    pub predicate: String,  // TODO: Replace with proper predicate AST
}

/// Unit type (for units of measure)
#[derive(Debug, Clone, PartialEq)]
pub struct UnitType {
    /// Base units with their powers
    /// e.g., m^1 * s^-2 for acceleration
    pub dimensions: HashMap<String, i32>,
}

impl Type {
    pub fn is_primitive(&self) -> bool {
        matches!(self,
            Type::Unit | Type::Bool |
            Type::I8 | Type::I16 | Type::I32 | Type::I64 | Type::I128 | Type::Int |
            Type::U8 | Type::U16 | Type::U32 | Type::U64 | Type::U128 | Type::UInt |
            Type::F32 | Type::F64 |
            Type::Char | Type::String
        )
    }
    
    pub fn is_numeric(&self) -> bool {
        matches!(self,
            Type::I8 | Type::I16 | Type::I32 | Type::I64 | Type::I128 | Type::Int |
            Type::U8 | Type::U16 | Type::U32 | Type::U64 | Type::U128 | Type::UInt |
            Type::F32 | Type::F64
        )
    }
    
    pub fn is_integer(&self) -> bool {
        matches!(self,
            Type::I8 | Type::I16 | Type::I32 | Type::I64 | Type::I128 | Type::Int |
            Type::U8 | Type::U16 | Type::U32 | Type::U64 | Type::U128 | Type::UInt
        )
    }
    
    pub fn is_float(&self) -> bool {
        matches!(self, Type::F32 | Type::F64)
    }
    
    pub fn is_linear(&self) -> bool {
        matches!(self, Type::Linear(_))
    }
    
    pub fn is_affine(&self) -> bool {
        matches!(self, Type::Affine(_))
    }
    
    pub fn is_copy(&self) -> bool {
        // Linear and affine types are not Copy
        if self.is_linear() || self.is_affine() {
            return false;
        }
        
        // References are Copy
        if matches!(self, Type::Ref(_, _)) {
            return true;
        }
        
        // Primitives are Copy
        self.is_primitive()
    }
}

impl EffectSet {
    pub fn empty() -> Self {
        Self { effects: Vec::new() }
    }
    
    pub fn pure() -> Self {
        Self::empty()
    }
    
    pub fn is_pure(&self) -> bool {
        self.effects.is_empty()
    }
    
    pub fn add(&mut self, effect: Effect) {
        if !self.effects.contains(&effect) {
            self.effects.push(effect);
        }
    }
    
    pub fn union(&self, other: &EffectSet) -> EffectSet {
        let mut result = self.clone();
        for e in &other.effects {
            result.add(e.clone());
        }
        result
    }
    
    pub fn contains(&self, effect: &Effect) -> bool {
        self.effects.contains(effect)
    }
}

impl UnitType {
    pub fn dimensionless() -> Self {
        Self { dimensions: HashMap::new() }
    }
    
    pub fn base(name: &str) -> Self {
        let mut dims = HashMap::new();
        dims.insert(name.to_string(), 1);
        Self { dimensions: dims }
    }
    
    pub fn multiply(&self, other: &UnitType) -> UnitType {
        let mut dims = self.dimensions.clone();
        for (unit, power) in &other.dimensions {
            *dims.entry(unit.clone()).or_insert(0) += power;
        }
        dims.retain(|_, v| *v != 0);
        UnitType { dimensions: dims }
    }
    
    pub fn divide(&self, other: &UnitType) -> UnitType {
        let mut dims = self.dimensions.clone();
        for (unit, power) in &other.dimensions {
            *dims.entry(unit.clone()).or_insert(0) -= power;
        }
        dims.retain(|_, v| *v != 0);
        UnitType { dimensions: dims }
    }
    
    pub fn is_dimensionless(&self) -> bool {
        self.dimensions.is_empty()
    }
}
