//! # Demetrios Type System
//!
//! Core type definitions and type checking infrastructure.
//!
//! ## Type Categories
//!
//! - **Primitives**: int, float, bool, char, string
//! - **References**: &T (shared), &!T (exclusive)
//! - **Ownership**: own T, linear T, affine T
//! - **Compounds**: tuples, arrays, structs, enums
//! - **Functions**: fn(A) -> B with E
//! - **Refined**: { x: T | predicate }
//! - **Units**: T<unit>

pub mod core;
pub mod ownership;
pub mod effects;
pub mod refinement;
pub mod units;

pub use self::core::*;
