//! Ownership and borrowing rules

use super::core::*;

/// Ownership state of a value
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OwnershipState {
    /// Value is owned
    Owned,
    /// Value has been moved
    Moved,
    /// Value is borrowed (shared)
    BorrowedShared(u32),  // Count of active borrows
    /// Value is borrowed (exclusive)
    BorrowedExclusive,
    /// Value has been dropped
    Dropped,
}

/// Borrow information
#[derive(Debug, Clone)]
pub struct BorrowInfo {
    pub kind: BorrowKind,
    pub lifetime: LifetimeId,
}

/// Borrow kind
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BorrowKind {
    Shared,
    Exclusive,
}

/// Lifetime identifier
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct LifetimeId(pub u32);

/// Ownership checker
pub struct OwnershipChecker {
    // State for each local variable
    states: Vec<OwnershipState>,
}

impl OwnershipChecker {
    pub fn new() -> Self {
        Self { states: Vec::new() }
    }
    
    /// Check if a value can be moved
    pub fn can_move(&self, local: usize) -> bool {
        matches!(self.states.get(local), Some(OwnershipState::Owned))
    }
    
    /// Check if a value can be borrowed (shared)
    pub fn can_borrow_shared(&self, local: usize) -> bool {
        matches!(
            self.states.get(local),
            Some(OwnershipState::Owned) | Some(OwnershipState::BorrowedShared(_))
        )
    }
    
    /// Check if a value can be borrowed (exclusive)
    pub fn can_borrow_exclusive(&self, local: usize) -> bool {
        matches!(self.states.get(local), Some(OwnershipState::Owned))
    }
}

impl Default for OwnershipChecker {
    fn default() -> Self {
        Self::new()
    }
}
